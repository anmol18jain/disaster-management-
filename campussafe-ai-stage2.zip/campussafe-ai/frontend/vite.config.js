import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// Vite = the dev server and build tool.
// - react(): lets Vite understand JSX and enables instant reload while you edit.
// - tailwindcss(): turns the Tailwind classes you write into real CSS.
export default defineConfig({
  plugins: [react(), tailwindcss()],
})
