import { EMERGENCY_TYPES } from '../data/emergencyTypes.js'
import { PATH_TAGS, PLACE_KINDS } from './campus.js'

const KIND_IDS = PLACE_KINDS.map((kind) => kind.id)
const TYPE_IDS = EMERGENCY_TYPES.map((type) => type.id)
const TAG_IDS = PATH_TAGS.map((tag) => tag.id)

const text = (value, max) => (typeof value === 'string' ? value.trim().slice(0, max) : '')

/**
 * Checks and cleans survey data (from storage or an imported file).
 * Bad entries are skipped and reported, so one mistake can't break the map.
 * Returns { ok, data, skipped } where skipped is a list of messages.
 */
export function validateSurvey(raw) {
  if (!raw || typeof raw !== 'object' || !Array.isArray(raw.places) || !Array.isArray(raw.paths)) {
    return { ok: false, data: null, skipped: ['This is not a CampusSafe survey file (it needs "places" and "paths" lists).'] }
  }

  const skipped = []
  const places = []
  const ids = new Set()

  raw.places.forEach((place, index) => {
    const label = `Place ${index + 1}`
    const lat = Number(place?.lat)
    const lng = Number(place?.lng)
    if (typeof place?.id !== 'string' || !place.id || place.id.length > 100 || ids.has(place.id)) {
      skipped.push(`${label}: missing or duplicate id.`)
      return
    }
    if (!KIND_IDS.includes(place.kind)) {
      skipped.push(`${label}: unknown kind "${String(place.kind)}".`)
      return
    }
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
      skipped.push(`${label}: invalid position.`)
      return
    }
    ids.add(place.id)
    places.push({
      id: place.id,
      kind: place.kind,
      name: text(place.name, 80) || 'Unnamed place',
      lat,
      lng,
      floors: Number.isInteger(place.floors) && place.floors >= 0 && place.floors < 100 ? place.floors : null,
      description: text(place.description, 300),
      suitableFor: Array.isArray(place.suitableFor) ? [...new Set(place.suitableFor.filter((id) => TYPE_IDS.includes(id)))] : [],
      verified: place.verified === true,
    })
  })

  const paths = []
  const pairs = new Set()
  raw.paths.forEach((path, index) => {
    const label = `Walkway ${index + 1}`
    if (typeof path?.id !== 'string' || !path.id || !ids.has(path.from) || !ids.has(path.to) || path.from === path.to) {
      skipped.push(`${label}: missing id, or it doesn't connect two existing places.`)
      return
    }
    const pairKey = [path.from, path.to].sort().join('|')
    if (pairs.has(pairKey)) {
      skipped.push(`${label}: duplicate walkway.`)
      return
    }
    pairs.add(pairKey)
    paths.push({
      id: path.id.slice(0, 100),
      from: path.from,
      to: path.to,
      stepFree: path.stepFree === true,
      tags: Array.isArray(path.tags) ? [...new Set(path.tags.filter((tag) => TAG_IDS.includes(tag)))] : [],
      verified: path.verified === true,
    })
  })

  const center = raw.view?.center
  const view =
    Array.isArray(center) && center.length === 2 && center.every(Number.isFinite) && Number.isFinite(raw.view.zoom)
      ? { center: [center[0], center[1]], zoom: raw.view.zoom }
      : null

  return { ok: true, data: { places, paths, view }, skipped }
}

/** The JSON file written by "Export survey". */
export function buildSurveyExport(campus) {
  return {
    format: 'campussafe-survey',
    version: 1,
    campusId: campus.id,
    campusName: campus.name,
    exportedAt: new Date().toISOString(),
    view: campus.hasSavedView ? campus.view : null,
    places: campus.places,
    paths: campus.paths,
  }
}
