const EARTH_RADIUS_M = 6371000

/** A typical calm walking pace. Crowds, stairs and smoke make people slower. */
export const WALKING_SPEED_MPS = 1.2

/** Straight-line distance in metres between two { lat, lng } points on Earth. */
export function haversineMeters(a, b) {
  const toRad = (deg) => (deg * Math.PI) / 180
  const dLat = toRad(b.lat - a.lat)
  const dLng = toRad(b.lng - a.lng)
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2
  return 2 * EARTH_RADIUS_M * Math.asin(Math.sqrt(h))
}

/**
 * Distance in metres for either kind of campus:
 * real campuses use latitude/longitude; the demo campus uses plain metres.
 */
export function distanceMeters(campus, a, b) {
  if (campus.crs === 'simple') return Math.hypot(a.lat - b.lat, a.lng - b.lng)
  return haversineMeters(a, b)
}

export function formatDistance(meters) {
  if (meters < 1000) return `${Math.round(meters)} m`
  return `${(meters / 1000).toFixed(1)} km`
}

/** The closest place of the given kinds to a point, or null. */
export function findNearestPlace(campus, point, kinds) {
  let best = null
  for (const place of campus.places) {
    if (!kinds.includes(place.kind)) continue
    const distance = distanceMeters(campus, point, place)
    if (!best || distance < best.distance) best = { place, distance }
  }
  return best
}
