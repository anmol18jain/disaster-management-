/** Makes text safe to put inside HTML (map labels are built as HTML strings). */
export function escapeHtml(text) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }
  return String(text).replace(/[&<>"']/g, (character) => map[character])
}
