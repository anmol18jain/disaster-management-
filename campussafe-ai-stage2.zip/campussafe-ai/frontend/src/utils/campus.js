import { EMERGENCY_TYPES } from '../data/emergencyTypes.js'

/** Kinds of place you can put on a campus map. */
export const PLACE_KINDS = [
  { id: 'building', label: 'Building' },
  { id: 'gate', label: 'Gate or campus exit' },
  { id: 'assembly', label: 'Assembly point' },
  { id: 'refuge', label: 'Refuge or shelter' },
  { id: 'junction', label: 'Walkway junction or door' },
]

/** Kinds a person can start from. */
export const START_KINDS = ['building', 'gate']

/** Tags for walkways. Stage 3 routing uses them to exclude risky paths. */
export const PATH_TAGS = [
  { id: 'low-lying', label: 'Low-lying (floods first)' },
  { id: 'slope', label: 'Along a slope or road cutting' },
  { id: 'near-buildings', label: 'Close to buildings or glass' },
  { id: 'narrow', label: 'Narrow (crowding risk)' },
  { id: 'unlit', label: 'Unlit at night' },
]

export function findPlace(campus, id) {
  if (!id) return null
  return campus.places.find((place) => place.id === id) ?? null
}

export function findEmergencyType(id) {
  return EMERGENCY_TYPES.find((type) => type.id === id) ?? null
}

/** Buildings and gates, sorted by name, for "where are you?" lists. */
export function getStartPlaces(campus) {
  return campus.places
    .filter((place) => START_KINDS.includes(place.kind))
    .sort((a, b) => a.name.localeCompare(b.name))
}

/**
 * Places marked as suitable destinations for this emergency type.
 * An empty list means "nothing approved", and the UI must say so.
 */
export function getEligibleDestinations(campus, emergencyTypeId) {
  if (!emergencyTypeId) return []
  return campus.places.filter((place) => place.suitableFor?.includes(emergencyTypeId))
}

/** A short summary for status displays. */
export function describeCampusData(campus) {
  const mapped = campus.places.filter((place) => place.kind !== 'junction').length
  const unverified = campus.places.filter((place) => !place.verified).length + campus.paths.filter((path) => !path.verified).length
  return { mapped, unverified, paths: campus.paths.length }
}
