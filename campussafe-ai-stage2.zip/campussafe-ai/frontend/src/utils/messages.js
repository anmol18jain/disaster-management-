function timeNow() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

function gpsLines(position) {
  if (!position) return []
  const lat = position.lat.toFixed(6)
  const lng = position.lng.toFixed(6)
  return [
    `GPS: ${lat}, ${lng} (accurate to about ${position.accuracy} m; less reliable indoors).`,
    `Map: https://maps.google.com/?q=${lat},${lng}`,
  ]
}

/** Text for asking someone for help. */
export function buildHelpMessage({ campusName, placeName, details, position }) {
  const where = [placeName, details?.trim()].filter(Boolean).join(', ')
  return [
    'EMERGENCY: I need help.',
    `Location: ${where || 'not given'} (${campusName}).`,
    ...gpsLines(position),
    `Sent at ${timeNow()}.`,
  ].join('\n')
}

/** Text for telling people you are safe. */
export function buildSafeMessage({ campusName, placeName, note }) {
  return [
    `I'm safe. I'm at ${placeName || 'a safe place'} (${campusName}).`,
    note?.trim() ? note.trim() : null,
    `Sent at ${timeNow()}.`,
  ]
    .filter(Boolean)
    .join('\n')
}
