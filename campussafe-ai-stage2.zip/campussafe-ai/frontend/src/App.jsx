import { Route, Routes } from 'react-router-dom'
import AppLayout from './components/layout/AppLayout.jsx'
import ContactsPage from './pages/ContactsPage.jsx'
import DashboardPage from './pages/DashboardPage.jsx'
import GuidePage from './pages/GuidePage.jsx'
import LandingPage from './pages/LandingPage.jsx'
import MapperPage from './pages/MapperPage.jsx'
import NotFoundPage from './pages/NotFoundPage.jsx'
import SosPage from './pages/SosPage.jsx'
import UpcomingPage from './pages/UpcomingPage.jsx'

const ADMIN_PLAN = {
  title: 'Admin dashboard (demo)',
  stage: 5,
  summary: 'A control view for campus safety staff, built on the same map and routing engine.',
  items: [
    'See the campus map with every hazard and closed path',
    'Close walkways or corridors, and reopen them later',
    'Post simulated emergency alerts',
    'Mark hazard zones on the map',
    'Add or edit buildings and evacuation destinations',
    'Check which routes are open, rerouted or unavailable',
  ],
  note: 'Admin controls in this prototype run in the browser and are not secured. A real deployment needs server-side sign-in, permissions and an audit log (planned for Stage 6).',
}

/**
 * Page routes.
 * "/" is the landing page. The other pages share AppLayout (sidebar + top bar).
 */
export default function App() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route element={<AppLayout />}>
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/sos" element={<SosPage />} />
        <Route path="/guide" element={<GuidePage />} />
        <Route path="/mapper" element={<MapperPage />} />
        <Route path="/contacts" element={<ContactsPage />} />
        <Route path="/admin" element={<UpcomingPage {...ADMIN_PLAN} />} />
      </Route>
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  )
}
