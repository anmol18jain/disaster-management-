import { useEmergency } from '../context/EmergencyContext.jsx'

/** Small campus status badge for the top bar. Always says it is simulated. */
export default function StatusPill() {
  const { emergencyMode } = useEmergency()

  if (emergencyMode) {
    return (
      <span
        className="inline-flex items-center gap-2 rounded-full border border-danger/50 bg-danger/15 px-3 py-1 text-xs font-semibold text-red-100"
        title="A simulated emergency is running"
      >
        <span className="relative flex size-2">
          <span className="absolute inline-flex size-full animate-ping-slow rounded-full bg-danger" />
          <span className="relative inline-flex size-2 rounded-full bg-danger" />
        </span>
        Emergency (simulated)
      </span>
    )
  }

  return (
    <span
      className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-medium text-slate-300"
      title="No simulated alerts. Live hazard data is not connected."
    >
      <span className="size-2 rounded-full bg-safe" aria-hidden="true" />
      Normal (simulated)
    </span>
  )
}
