import { ShieldCheck } from 'lucide-react'

/** CampusSafe AI wordmark. `compact` shows only the shield. */
export default function Logo({ compact = false }) {
  return (
    <span className="inline-flex items-center gap-2.5">
      <span className="grid size-9 place-items-center rounded-xl bg-teal-400 text-navy-950">
        <ShieldCheck className="size-5" strokeWidth={2.4} aria-hidden="true" />
      </span>
      {!compact && (
        <span className="font-display text-xl font-bold tracking-tight text-white">CampusSafe AI</span>
      )}
    </span>
  )
}
