import { TriangleAlert } from 'lucide-react'

/** Thin strip shown on every page so nobody mistakes the demo for a live system. */
export default function PrototypeNotice() {
  return (
    <div
      role="note"
      className="flex items-center justify-center gap-2 border-b border-caution/25 bg-caution/10 px-4 py-2 text-center text-xs text-amber-100 sm:text-sm"
    >
      <TriangleAlert className="hidden size-4 shrink-0 text-caution sm:block" aria-hidden="true" />
      <p>
        <strong className="font-semibold text-caution">Prototype with fictional data.</strong> In a real emergency,
        follow authorized campus emergency personnel.
      </p>
    </div>
  )
}
