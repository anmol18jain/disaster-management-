/**
 * Hero illustration styled like the evacuation plans mounted on building walls.
 * One short animation tells the product story:
 *   1. a route is drawn from "You are here" to Assembly Point A
 *   2. a hazard is reported on that path, so the route fades out
 *   3. a longer but safe detour is drawn instead
 * Fictional layout. Purely decorative, so the real logic lives elsewhere.
 */
export default function EvacuationPlanIllustration() {
  return (
    <figure className="rounded-3xl border border-white/10 bg-navy-900 p-4 shadow-2xl shadow-black/40 sm:p-6">
      <div className="flex items-baseline justify-between gap-4">
        <span className="font-display text-lg font-semibold text-white">Evacuation plan</span>
        <span className="text-sm text-slate-400">Fictional layout</span>
      </div>

      <svg viewBox="0 0 480 340" className="mt-3 w-full" role="img" aria-labelledby="plan-title plan-desc">
        <title id="plan-title">Illustration of a route being recalculated</title>
        <desc id="plan-desc">
          The direct route from the library to Assembly Point A is blocked by a reported hazard, so a longer route around
          the engineering building is shown instead.
        </desc>

        <defs>
          <pattern id="plan-grid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M20 0H0V20" fill="none" stroke="#94a3b8" strokeOpacity="0.07" />
          </pattern>
        </defs>
        <rect width="480" height="340" rx="14" fill="url(#plan-grid)" />

        {/* Walkways */}
        <g className="stroke-navy-700" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" fill="none">
          <path d="M100 155 H250 V60 H400" />
          <path d="M100 155 V250 H460 V60 H400" />
          <path d="M250 155 V250" />
        </g>

        {/* Buildings */}
        <g className="fill-navy-800 stroke-navy-600" strokeWidth="1.5">
          <rect x="40" y="105" width="120" height="100" rx="6" />
          <rect x="290" y="95" width="130" height="115" rx="6" />
          <rect x="160" y="275" width="130" height="50" rx="6" />
        </g>
        <g className="font-display" fontSize="15" fontWeight="600" fill="#94a3b8">
          <text x="52" y="126">Library</text>
          <text x="355" y="157" textAnchor="middle">
            Engineering
          </text>
          <text x="225" y="305" textAnchor="middle">
            Admin
          </text>
        </g>

        {/* Assembly point */}
        <text x="400" y="26" textAnchor="middle" className="fill-safe font-display" fontSize="14" fontWeight="600">
          Assembly point A
        </text>
        <rect x="378" y="38" width="44" height="44" rx="8" className="fill-safe" />
        <text x="400" y="68" textAnchor="middle" className="font-display" fontSize="22" fontWeight="700" fill="#07111f">
          A
        </text>

        {/* 1. Direct route (fades once the hazard appears) */}
        <path
          d="M100 155 H250 V60 H378"
          pathLength="1"
          className="plan-route plan-route-first stroke-safe"
          fill="none"
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* 3. Safe detour */}
        <path
          d="M100 155 V250 H460 V60 H422"
          pathLength="1"
          className="plan-route plan-route-second stroke-safe"
          fill="none"
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* 2. Hazard marker (warning-sign triangle) */}
        <g className="plan-hazard">
          <polygon
            points="250,86 272,124 228,124"
            className="fill-caution"
            stroke="#07111f"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
          <text x="250" y="119" textAnchor="middle" fontSize="20" fontWeight="700" fill="#07111f">
            !
          </text>
          <text x="222" y="110" textAnchor="end" className="fill-caution font-display" fontSize="14" fontWeight="600">
            Blocked
          </text>
        </g>

        {/* You are here */}
        <circle cx="100" cy="155" r="9" className="plan-ping animate-ping-slow fill-danger" />
        <circle cx="100" cy="155" r="8" className="fill-danger" stroke="#fff" strokeWidth="2.5" />
        <text x="100" y="94" textAnchor="middle" className="font-display" fontSize="14" fontWeight="600" fill="#fff">
          You are here
        </text>
      </svg>

      <figcaption className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-sm text-slate-300">
        <span className="inline-flex items-center gap-2">
          <span className="size-3 rounded-full bg-danger" aria-hidden="true" /> You are here
        </span>
        <span className="inline-flex items-center gap-2">
          <span className="h-1 w-6 rounded-full bg-safe" aria-hidden="true" /> Safe route
        </span>
        <span className="inline-flex items-center gap-2">
          <span className="size-3 rotate-45 bg-caution" aria-hidden="true" /> Reported hazard
        </span>
      </figcaption>
    </figure>
  )
}
