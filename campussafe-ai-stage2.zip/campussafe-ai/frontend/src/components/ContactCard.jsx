import { Phone, PhoneOff } from 'lucide-react'

/**
 * One emergency contact.
 * If no verified number is configured, it says so and offers no call button.
 */
export default function ContactCard({ contact, compact = false }) {
  const configured = Boolean(contact.phone)
  const dialable = configured ? contact.phone.replace(/[^\d+]/g, '') : ''

  return (
    <div
      className={
        compact
          ? 'flex items-center gap-4 py-3'
          : 'flex items-center gap-4 rounded-2xl border border-white/10 bg-navy-900 p-5'
      }
    >
      <div className="min-w-0 flex-1">
        <p className={compact ? 'font-medium text-white' : 'font-display text-lg font-semibold text-white'}>
          {contact.name}
        </p>
        {!compact && <p className="mt-1 text-sm text-slate-400">{contact.description}</p>}
        {!compact && contact.source && <p className="mt-1 text-xs text-slate-500">Source: {contact.source}</p>}
        <p className={`mt-1 text-sm ${configured ? 'font-semibold text-teal-200' : 'text-caution'}`}>
          {configured ? contact.phone : 'Number not configured'}
        </p>
      </div>

      {configured ? (
        <a
          href={`tel:${dialable}`}
          className="inline-flex shrink-0 items-center gap-2 rounded-lg bg-teal-400 px-3 py-2 text-sm font-semibold text-navy-950 transition hover:bg-teal-300"
        >
          <Phone className="size-4" aria-hidden="true" />
          Call <span className="sr-only">{contact.name}</span>
        </a>
      ) : (
        <span
          className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-white/10 px-2.5 py-1.5 text-xs text-slate-400"
          title="Add a verified number in src/data/contacts.js"
        >
          <PhoneOff className="size-3.5" aria-hidden="true" />
          Can't call
        </span>
      )}
    </div>
  )
}
