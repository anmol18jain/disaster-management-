import { useState } from 'react'
import { EMERGENCY_TYPES } from '../../data/emergencyTypes.js'
import { PLACE_KINDS } from '../../utils/campus.js'

const inputClass =
  'w-full rounded-lg border border-white/15 bg-navy-850 px-3 py-2 text-sm text-white placeholder:text-slate-500 hover:border-white/30'

/**
 * Form to add or edit a place on the campus map.
 * The parent should give it a `key` so it resets when a different place is opened.
 */
export default function PlaceForm({ initial, heading, submitLabel, onSave, onCancel, onDelete }) {
  const [name, setName] = useState(initial.name ?? '')
  const [kind, setKind] = useState(initial.kind ?? 'building')
  const [floors, setFloors] = useState(initial.floors ?? '')
  const [description, setDescription] = useState(initial.description ?? '')
  const [suitableFor, setSuitableFor] = useState(initial.suitableFor ?? [])
  const [verified, setVerified] = useState(initial.verified ?? false)
  const [error, setError] = useState('')

  const canBeDestination = kind !== 'junction'

  function toggleType(typeId) {
    setSuitableFor((current) => (current.includes(typeId) ? current.filter((id) => id !== typeId) : [...current, typeId]))
  }

  function handleSubmit(event) {
    event.preventDefault()
    const trimmed = name.trim()
    if (!trimmed) {
      setError('Give this place a name, for example "Block 5 main entrance".')
      return
    }
    const floorCount = Number.parseInt(floors, 10)
    onSave({
      name: trimmed.slice(0, 80),
      kind,
      floors: kind === 'building' && Number.isInteger(floorCount) && floorCount >= 0 && floorCount < 100 ? floorCount : null,
      description: description.trim().slice(0, 300),
      suitableFor: canBeDestination ? suitableFor : [],
      verified,
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4" noValidate>
      <h3 className="font-display text-lg font-semibold text-white">{heading}</h3>

      <div>
        <label htmlFor="place-name" className="mb-1.5 block text-sm font-medium text-slate-300">
          Name
        </label>
        <input
          id="place-name"
          value={name}
          onChange={(event) => setName(event.target.value)}
          maxLength={80}
          className={inputClass}
          aria-invalid={Boolean(error)}
          aria-describedby={error ? 'place-name-error' : undefined}
          autoFocus
        />
        {error && (
          <p id="place-name-error" className="mt-1 text-sm text-danger">
            {error}
          </p>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="place-kind" className="mb-1.5 block text-sm font-medium text-slate-300">
            Type
          </label>
          <select id="place-kind" value={kind} onChange={(event) => setKind(event.target.value)} className={inputClass}>
            {PLACE_KINDS.map((option) => (
              <option key={option.id} value={option.id}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        {kind === 'building' && (
          <div>
            <label htmlFor="place-floors" className="mb-1.5 block text-sm font-medium text-slate-300">
              Floors
            </label>
            <input
              id="place-floors"
              type="number"
              min="0"
              max="99"
              inputMode="numeric"
              value={floors}
              onChange={(event) => setFloors(event.target.value)}
              className={inputClass}
            />
          </div>
        )}
      </div>

      <div>
        <label htmlFor="place-description" className="mb-1.5 block text-sm font-medium text-slate-300">
          Notes <span className="font-normal text-slate-500">(optional)</span>
        </label>
        <textarea
          id="place-description"
          rows={2}
          maxLength={300}
          value={description}
          onChange={(event) => setDescription(event.target.value)}
          placeholder="Exits, labs, what's nearby"
          className={inputClass}
        />
      </div>

      {canBeDestination && (
        <fieldset>
          <legend className="text-sm font-medium text-slate-300">Official evacuation destination for</legend>
          <p className="mt-1 text-xs text-slate-500">
            Only tick these if UPES safety staff or signage designate this place. Otherwise leave them all empty.
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            {EMERGENCY_TYPES.map((type) => (
              <label
                key={type.id}
                className={`inline-flex items-center gap-2 rounded-lg border px-2.5 py-1.5 text-sm ${
                  suitableFor.includes(type.id) ? 'border-safe/60 bg-safe/10 text-white' : 'border-white/10 text-slate-300'
                }`}
              >
                <input type="checkbox" checked={suitableFor.includes(type.id)} onChange={() => toggleType(type.id)} className="accent-teal-400" />
                {type.label}
              </label>
            ))}
          </div>
        </fieldset>
      )}

      <label className="flex items-start gap-3 rounded-lg bg-navy-850 p-3 text-sm text-slate-300">
        <input type="checkbox" checked={verified} onChange={(event) => setVerified(event.target.checked)} className="mt-0.5 accent-teal-400" />
        <span>
          <span className="font-medium text-white">Verified on site</span>
          <span className="block text-xs text-slate-500">I checked the position and details in person or against an official plan.</span>
        </span>
      </label>

      <div className="flex flex-wrap items-center gap-2">
        <button type="submit" className="rounded-lg bg-teal-400 px-4 py-2 text-sm font-semibold text-navy-950 hover:bg-teal-300">
          {submitLabel}
        </button>
        <button type="button" onClick={onCancel} className="rounded-lg px-4 py-2 text-sm font-semibold text-slate-300 hover:bg-white/5 hover:text-white">
          Cancel
        </button>
        {onDelete && (
          <button
            type="button"
            onClick={onDelete}
            className="ml-auto rounded-lg border border-danger/40 px-4 py-2 text-sm font-semibold text-red-200 hover:bg-danger/15"
          >
            Delete place
          </button>
        )}
      </div>
    </form>
  )
}
