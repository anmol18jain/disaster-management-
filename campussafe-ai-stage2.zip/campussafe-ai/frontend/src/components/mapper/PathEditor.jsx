import { PATH_TAGS, findPlace } from '../../utils/campus.js'
import { distanceMeters, formatDistance, WALKING_SPEED_MPS } from '../../utils/geo.js'

/** Edit one walkway: step-free or not, risk tags, verified, delete. Changes save immediately. */
export default function PathEditor({ campus, path, onChange, onDelete, onClose }) {
  const from = findPlace(campus, path.from)
  const to = findPlace(campus, path.to)
  const length = from && to ? distanceMeters(campus, from, to) : 0

  function toggleTag(tagId) {
    onChange({ tags: path.tags.includes(tagId) ? path.tags.filter((id) => id !== tagId) : [...path.tags, tagId] })
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-display text-lg font-semibold text-white">Walkway</h3>
        <p className="text-sm text-slate-400">
          {from?.name ?? '?'} to {to?.name ?? '?'}: {formatDistance(length)}, about {Math.max(1, Math.round(length / WALKING_SPEED_MPS))} s
          walking
        </p>
      </div>

      <label className="flex items-start gap-3 text-sm text-slate-300">
        <input type="checkbox" checked={path.stepFree} onChange={(event) => onChange({ stepFree: event.target.checked })} className="mt-0.5 accent-teal-400" />
        <span>
          <span className="font-medium text-white">Step-free</span>
          <span className="block text-xs text-slate-500">No stairs or steps, usable with a wheelchair.</span>
        </span>
      </label>

      <fieldset>
        <legend className="text-sm font-medium text-slate-300">Risks on this walkway</legend>
        <div className="mt-2 space-y-2">
          {PATH_TAGS.map((tag) => (
            <label key={tag.id} className="flex items-center gap-3 text-sm text-slate-300">
              <input type="checkbox" checked={path.tags.includes(tag.id)} onChange={() => toggleTag(tag.id)} className="accent-teal-400" />
              {tag.label}
            </label>
          ))}
        </div>
      </fieldset>

      <label className="flex items-start gap-3 text-sm text-slate-300">
        <input type="checkbox" checked={path.verified} onChange={(event) => onChange({ verified: event.target.checked })} className="mt-0.5 accent-teal-400" />
        <span className="font-medium text-white">Verified on site</span>
      </label>

      <div className="flex flex-wrap gap-2">
        <button type="button" onClick={onClose} className="rounded-lg px-4 py-2 text-sm font-semibold text-slate-300 hover:bg-white/5 hover:text-white">
          Done
        </button>
        <button
          type="button"
          onClick={onDelete}
          className="ml-auto rounded-lg border border-danger/40 px-4 py-2 text-sm font-semibold text-red-200 hover:bg-danger/15"
        >
          Delete walkway
        </button>
      </div>
    </div>
  )
}
