import { useCampus } from '../context/CampusContext.jsx'

/** Dropdown to switch between your real campus survey and the fictional demo. */
export default function CampusSwitcher({ id = 'campus-switcher' }) {
  const { campuses, activeCampusId, setActiveCampusId } = useCampus()

  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm font-semibold text-slate-200">
        Campus
      </label>
      <select
        id={id}
        value={activeCampusId}
        onChange={(event) => setActiveCampusId(event.target.value)}
        className="w-full rounded-lg border border-white/15 bg-navy-850 px-3 py-2 text-sm text-white"
      >
        {campuses.map((campus) => (
          <option key={campus.id} value={campus.id}>
            {campus.shortName}
            {campus.isFictional ? ' (fictional demo)' : ''}
          </option>
        ))}
      </select>
    </div>
  )
}
