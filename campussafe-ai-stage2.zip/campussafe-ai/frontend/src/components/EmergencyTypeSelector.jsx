import { EMERGENCY_TYPES } from '../data/emergencyTypes.js'
import EmergencyIcon, { EMERGENCY_SELECTED_STYLES } from './EmergencyIcon.jsx'

/**
 * Lets the user pick the type of emergency.
 * Uses real radio buttons (visually hidden) so it works with keyboards and screen readers.
 * - size "compact": chips (dashboard)
 * - size "large":   cards with a short summary (emergency dialog)
 * `name` must be different for each copy on the same page.
 */
export default function EmergencyTypeSelector({ value, onChange, size = 'compact', name = 'emergency-type' }) {
  const large = size === 'large'

  return (
    <fieldset>
      <legend className={large ? 'mb-3 text-sm text-slate-300' : 'mb-2 text-sm font-medium text-slate-300'}>
        {large ? 'What kind of emergency is it?' : 'Emergency type'}
      </legend>
      <div className={large ? 'grid gap-2 sm:grid-cols-2' : 'flex flex-wrap gap-2'}>
        {EMERGENCY_TYPES.map((type) => {
          const checked = value === type.id
          const stateClasses = checked
            ? EMERGENCY_SELECTED_STYLES[type.id]
            : 'border-white/10 text-slate-300 hover:border-white/25 hover:bg-white/5 hover:text-white'

          return (
            <label
              key={type.id}
              className={`rounded-xl border transition-colors has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-teal-300 ${stateClasses} ${
                large ? 'flex items-start gap-3 p-3.5' : 'inline-flex items-center gap-2 px-3 py-2 text-sm font-medium'
              }`}
            >
              <input
                type="radio"
                name={name}
                value={type.id}
                checked={checked}
                onChange={() => onChange(type.id)}
                className="sr-only"
              />
              <EmergencyIcon typeId={type.id} className={large ? 'mt-0.5 size-5 shrink-0' : 'size-4'} />
              {large ? (
                <span>
                  <span className="block font-semibold text-white">{type.label}</span>
                  <span className="block text-sm text-slate-400">{type.summary}</span>
                </span>
              ) : (
                <span>{type.label}</span>
              )}
            </label>
          )
        })}
      </div>
    </fieldset>
  )
}
