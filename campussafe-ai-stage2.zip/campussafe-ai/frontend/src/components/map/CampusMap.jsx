import { useEffect, useMemo } from 'react'
import L from 'leaflet'
import { Circle, LayersControl, MapContainer, Marker, Polyline, TileLayer, useMap, useMapEvents } from 'react-leaflet'
import { placeIcon, USER_ICON } from './mapIcons.js'

// Free map tiles. Both need visible attribution. Check their usage policies before a public launch.
const STREET_TILES = {
  url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
}
const SATELLITE_TILES = {
  url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
  attribution: 'Imagery &copy; Esri, Maxar, Earthstar Geographics',
}

/** Sends map clicks (not marker clicks) to the parent. */
function ClickHandler({ onMapClick }) {
  useMapEvents({
    click(event) {
      onMapClick({ lat: event.latlng.lat, lng: event.latlng.lng })
    },
  })
  return null
}

/** Gives the parent access to the Leaflet map, e.g. to read the current view. */
function MapReady({ onReady }) {
  const map = useMap()
  useEffect(() => {
    onReady(map)
  }, [map, onReady])
  return null
}

/** Moves the map to a point whenever `target` changes. */
function FlyTo({ target }) {
  const map = useMap()
  useEffect(() => {
    if (target) map.flyTo([target.lat, target.lng], Math.max(map.getZoom(), 18))
  }, [map, target])
  return null
}

/**
 * The campus map, shared by the dashboard and the campus mapper.
 * - Real campuses: OpenStreetMap or satellite tiles, positions in latitude/longitude.
 * - Demo campus: a blank canvas (Leaflet CRS.Simple), positions in metres.
 */
export default function CampusMap({
  campus,
  className = 'h-[420px]',
  selectedPlaceId = null,
  highlightedPlaceIds = [],
  pendingPlaceId = null,
  selectedPathId = null,
  draggablePlaceId = null,
  showJunctions = false,
  userPosition = null,
  flyToTarget = null,
  crosshair = false,
  onPlaceClick,
  onPathClick,
  onMapClick,
  onPlaceMove,
  onMapReady,
}) {
  const isSimple = campus.crs === 'simple'
  const placesById = useMemo(() => new Map(campus.places.map((place) => [place.id, place])), [campus.places])
  const highlighted = useMemo(() => new Set(highlightedPlaceIds), [highlightedPlaceIds])

  // MapContainer only reads these when it first appears, so the map is
  // re-created (via `key`) when the campus changes.
  const viewProps = isSimple
    ? { crs: L.CRS.Simple, bounds: campus.bounds, minZoom: -2, maxZoom: 3, zoomSnap: 0.25 }
    : { center: campus.view.center, zoom: campus.view.zoom, minZoom: 13, maxZoom: 19 }

  return (
    <div
      role="region"
      aria-label={`Map of ${campus.name}`}
      className={`relative isolate overflow-hidden rounded-2xl border border-white/10 ${className}`}
    >
      <MapContainer
        key={campus.id}
        {...viewProps}
        scrollWheelZoom
        className={`size-full ${isSimple ? 'cs-map-canvas' : ''}`}
      >
        {!isSimple && (
          <LayersControl position="topright">
            <LayersControl.BaseLayer checked name="Street map">
              <TileLayer url={STREET_TILES.url} attribution={STREET_TILES.attribution} maxZoom={19} />
            </LayersControl.BaseLayer>
            <LayersControl.BaseLayer name="Satellite">
              <TileLayer url={SATELLITE_TILES.url} attribution={SATELLITE_TILES.attribution} maxZoom={19} />
            </LayersControl.BaseLayer>
          </LayersControl>
        )}

        {campus.paths.map((path) => {
          const from = placesById.get(path.from)
          const to = placesById.get(path.to)
          if (!from || !to) return null
          const selected = path.id === selectedPathId
          return (
            <Polyline
              key={path.id}
              positions={[
                [from.lat, from.lng],
                [to.lat, to.lng],
              ]}
              bubblingMouseEvents={false}
              pathOptions={{
                color: selected ? '#fbbf24' : path.stepFree ? '#2dd4bf' : '#94a3b8',
                weight: selected ? 8 : 5,
                opacity: 0.95,
                dashArray: !campus.isFictional && !path.verified ? '8 8' : null,
              }}
              eventHandlers={onPathClick ? { click: () => onPathClick(path) } : {}}
            />
          )
        })}

        {campus.places.map((place) => {
          if (place.kind === 'junction' && !showJunctions && place.id !== pendingPlaceId) return null
          return (
            <Marker
              key={place.id}
              position={[place.lat, place.lng]}
              title={place.name}
              keyboard
              draggable={place.id === draggablePlaceId}
              zIndexOffset={place.id === selectedPlaceId ? 1000 : 0}
              icon={placeIcon(place, {
                selected: place.id === selectedPlaceId,
                highlighted: highlighted.has(place.id),
                pending: place.id === pendingPlaceId,
                unverified: !campus.isFictional && !place.verified,
              })}
              eventHandlers={{
                click: () => onPlaceClick?.(place),
                dragend: (event) => {
                  const position = event.target.getLatLng()
                  onPlaceMove?.(place.id, { lat: position.lat, lng: position.lng })
                },
              }}
            />
          )
        })}

        {userPosition && !isSimple && (
          <>
            <Circle
              center={[userPosition.lat, userPosition.lng]}
              radius={userPosition.accuracy}
              interactive={false}
              pathOptions={{ color: '#3b82f6', weight: 1, fillOpacity: 0.12 }}
            />
            <Marker position={[userPosition.lat, userPosition.lng]} icon={USER_ICON} interactive={false} keyboard={false} />
          </>
        )}

        {onMapClick && <ClickHandler onMapClick={onMapClick} />}
        {onMapReady && <MapReady onReady={onMapReady} />}
        <FlyTo target={flyToTarget} />
      </MapContainer>

      {crosshair && <div className="cs-crosshair" aria-hidden="true" />}
    </div>
  )
}
