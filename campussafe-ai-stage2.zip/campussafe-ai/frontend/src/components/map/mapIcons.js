import L from 'leaflet'
import { escapeHtml } from '../../utils/html.js'

/**
 * Map markers are small HTML elements (Leaflet "divIcons") styled in App.css
 * (.cs-pin ...). Names are escaped because they can come from imported files.
 */
export function placeIcon(place, { selected = false, highlighted = false, pending = false, unverified = false } = {}) {
  const classes = ['cs-pin', `cs-pin--${place.kind}`]
  if (selected) classes.push('is-selected')
  if (highlighted) classes.push('is-highlighted')
  if (pending) classes.push('is-pending')
  if (unverified) classes.push('is-unverified')

  const isJunction = place.kind === 'junction'
  const size = isJunction ? 14 : 22
  const label = isJunction ? '' : `<span class="cs-pin__label">${escapeHtml(place.name)}</span>`

  return L.divIcon({
    className: 'cs-pin-root',
    html: `<span class="${classes.join(' ')}"><span class="cs-pin__dot"></span>${label}</span>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  })
}

export const USER_ICON = L.divIcon({
  className: 'cs-pin-root',
  html: '<span class="cs-user"></span>',
  iconSize: [18, 18],
  iconAnchor: [9, 9],
})
