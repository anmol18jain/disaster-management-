import { TriangleAlert } from 'lucide-react'
import { useEmergency } from '../context/EmergencyContext.jsx'

/** Red banner shown across the app while emergency mode is on. */
export default function EmergencyBanner() {
  const { emergencyMode, selectedEmergency, endEmergency } = useEmergency()
  if (!emergencyMode) return null

  return (
    <div role="alert" className="border-b border-danger/40 bg-danger/15 px-4 py-3 sm:px-6 lg:px-8">
      <div className="mx-auto flex max-w-7xl flex-col gap-3 sm:flex-row sm:items-center">
        <div className="flex items-start gap-3">
          <TriangleAlert className="mt-0.5 size-5 shrink-0 text-danger" aria-hidden="true" />
          <p className="text-sm text-red-50">
            <strong className="font-semibold text-white">Emergency mode is a simulation.</strong>{' '}
            {selectedEmergency
              ? `Scenario: ${selectedEmergency.label}. `
              : 'Choose your location and the emergency type. '}
            Real evacuation instructions come only from authorized campus emergency personnel.
          </p>
        </div>
        <button
          type="button"
          onClick={endEmergency}
          className="shrink-0 self-start rounded-lg border border-red-200/40 px-3 py-1.5 text-sm font-semibold text-red-50 transition hover:bg-danger/25 sm:ml-auto sm:self-center"
        >
          End simulation
        </button>
      </div>
    </div>
  )
}
