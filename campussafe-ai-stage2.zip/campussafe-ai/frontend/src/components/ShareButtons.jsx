import { useState } from 'react'
import { Copy, MessageSquare, Send, Share2 } from 'lucide-react'

/** Copy / share / WhatsApp / SMS buttons for a ready-made message. */
export default function ShareButtons({ message, title = 'CampusSafe AI' }) {
  const [status, setStatus] = useState('')
  const canShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function'
  const encoded = encodeURIComponent(message)

  async function copy() {
    try {
      await navigator.clipboard.writeText(message)
      setStatus('Message copied.')
    } catch {
      setStatus('Could not copy automatically. Select the text and copy it.')
    }
  }

  async function share() {
    try {
      await navigator.share({ title, text: message })
      setStatus('')
    } catch (error) {
      if (error?.name !== 'AbortError') setStatus('Sharing failed. Try copying the message instead.')
    }
  }

  const buttonClass =
    'inline-flex items-center justify-center gap-2 rounded-lg border border-white/15 px-3 py-2 text-sm font-semibold text-white transition-colors hover:border-white/30 hover:bg-white/5'

  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {canShare && (
          <button type="button" onClick={share} className={buttonClass}>
            <Share2 className="size-4" aria-hidden="true" /> Share
          </button>
        )}
        <a href={`https://wa.me/?text=${encoded}`} target="_blank" rel="noreferrer" className={buttonClass}>
          <Send className="size-4" aria-hidden="true" /> WhatsApp
        </a>
        <a href={`sms:?&body=${encoded}`} className={buttonClass}>
          <MessageSquare className="size-4" aria-hidden="true" /> Text message
        </a>
        <button type="button" onClick={copy} className={buttonClass}>
          <Copy className="size-4" aria-hidden="true" /> Copy
        </button>
      </div>
      <p role="status" className="mt-2 min-h-5 text-xs text-slate-400">
        {status}
      </p>
    </div>
  )
}
