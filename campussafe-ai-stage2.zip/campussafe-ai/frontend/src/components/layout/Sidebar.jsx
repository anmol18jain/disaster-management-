import { useEffect } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { BookOpen, Database, LayoutDashboard, LifeBuoy, MapPin, MapPinned, Phone, Settings, WifiOff, X } from 'lucide-react'
import { useCampus } from '../../context/CampusContext.jsx'
import CampusSwitcher from '../CampusSwitcher.jsx'
import Logo from '../Logo.jsx'

const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/sos', label: 'SOS tools', icon: LifeBuoy },
  { to: '/guide', label: 'Survival guide', icon: BookOpen },
  { to: '/mapper', label: 'Campus mapper', icon: MapPinned },
  { to: '/contacts', label: 'Emergency contacts', icon: Phone },
  { to: '/admin', label: 'Admin (demo)', icon: Settings, badge: 'Stage 5' },
]

/**
 * Main navigation.
 * Large screens: always visible on the left.
 * Small screens: a drawer that slides in from the menu button.
 */
export default function Sidebar({ open, onClose }) {
  const { campus } = useCampus()
  const dataStatus = [
    { icon: Database, text: campus.isFictional ? 'Map: fictional demo campus' : 'Map: your survey (unofficial)' },
    { icon: WifiOff, text: 'Live hazard feed: not connected' },
    { icon: MapPin, text: 'Location: chosen by you' },
  ]
  // Close the drawer with the Escape key.
  useEffect(() => {
    if (!open) return undefined
    const handleKey = (event) => {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [open, onClose])

  return (
    <>
      {/* Dark overlay behind the drawer on small screens. Tapping it closes the drawer. */}
      <div
        className={`fixed inset-0 z-40 bg-black/60 transition-opacity lg:hidden ${
          open ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
        onClick={onClose}
        aria-hidden="true"
      />

      <aside
        id="app-sidebar"
        aria-label="Main navigation"
        className={`fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-white/10 bg-navy-900 transition-[transform,visibility] duration-300 lg:visible lg:translate-x-0 ${
          open ? 'visible translate-x-0' : 'invisible -translate-x-full'
        }`}
      >
        <div className="flex h-16 items-center justify-between px-5">
          <Link to="/" onClick={onClose} aria-label="CampusSafe AI home page">
            <Logo />
          </Link>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-white/5 hover:text-white lg:hidden"
            aria-label="Close navigation"
          >
            <X className="size-5" aria-hidden="true" />
          </button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
          {NAV_ITEMS.map(({ to, label, icon: Icon, badge }) => (
            <NavLink
              key={to}
              to={to}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-xl px-3 py-2.5 text-[15px] font-medium transition-colors ${
                  isActive
                    ? 'bg-teal-400/10 text-teal-100 ring-1 ring-teal-300/30'
                    : 'text-slate-300 hover:bg-white/5 hover:text-white'
                }`
              }
            >
              <Icon className="size-5 shrink-0" aria-hidden="true" />
              <span className="flex-1">{label}</span>
              {badge && (
                <span className="rounded-md bg-white/10 px-1.5 py-0.5 text-[11px] font-medium text-slate-300">{badge}</span>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="m-3 space-y-4 rounded-xl border border-white/10 bg-navy-850 p-4">
          <CampusSwitcher />
          <ul className="space-y-2.5 text-xs text-slate-400" aria-label="Data sources">
            {dataStatus.map(({ icon: Icon, text }) => (
              <li key={text} className="flex items-center gap-2">
                <Icon className="size-3.5 shrink-0 text-caution" aria-hidden="true" />
                {text}
              </li>
            ))}
          </ul>
        </div>
      </aside>
    </>
  )
}
