import { useCallback, useState } from 'react'
import { Outlet } from 'react-router-dom'
import EmergencyBanner from '../EmergencyBanner.jsx'
import PrototypeNotice from '../PrototypeNotice.jsx'
import Sidebar from './Sidebar.jsx'
import TopBar from './TopBar.jsx'

/**
 * Shared frame for the app pages: sidebar on the left, top bar, then the page.
 * <Outlet /> is where React Router places the current page.
 */
export default function AppLayout() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const closeNav = useCallback(() => setMobileNavOpen(false), [])

  return (
    <div className="min-h-dvh bg-navy-950">
      <Sidebar open={mobileNavOpen} onClose={closeNav} />

      {/* On large screens, leave room for the 16rem-wide fixed sidebar. */}
      <div className="flex min-h-dvh flex-col lg:pl-64">
        <PrototypeNotice />
        <TopBar onMenuClick={() => setMobileNavOpen(true)} />
        <EmergencyBanner />
        <main id="main-content" className="flex-1 px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
