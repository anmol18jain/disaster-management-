import { Menu, Siren } from 'lucide-react'
import { useLocation, useNavigate } from 'react-router-dom'
import { useEmergency } from '../../context/EmergencyContext.jsx'
import StatusPill from '../StatusPill.jsx'

const SECTION_NAMES = {
  '/dashboard': 'Dashboard',
  '/contacts': 'Emergency contacts',
  '/sos': 'SOS tools',
  '/guide': 'Survival guide',
  '/mapper': 'Campus mapper',
  '/admin': 'Admin (demo)',
}

/** Sticky bar at the top: menu button (mobile), section name, status and a quick emergency button. */
export default function TopBar({ onMenuClick }) {
  const { pathname } = useLocation()
  const navigate = useNavigate()
  const { emergencyMode, startEmergency } = useEmergency()

  function handleEmergency() {
    startEmergency()
    navigate('/dashboard')
  }

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-white/10 bg-navy-950/85 px-4 backdrop-blur-md sm:px-6 lg:px-8">
      <button
        type="button"
        onClick={onMenuClick}
        className="-ml-1 rounded-lg p-2 text-slate-300 transition-colors hover:bg-white/5 hover:text-white lg:hidden"
        aria-label="Open navigation"
        aria-controls="app-sidebar"
      >
        <Menu className="size-5" aria-hidden="true" />
      </button>

      <p className="truncate font-display text-lg font-semibold text-white">{SECTION_NAMES[pathname] ?? 'CampusSafe AI'}</p>

      <div className="ml-auto flex items-center gap-2 sm:gap-3">
        <StatusPill />
        {!emergencyMode && (
          <button
            type="button"
            onClick={handleEmergency}
            className="inline-flex items-center gap-2 rounded-xl bg-danger px-3 py-2 text-sm font-semibold text-white transition-colors hover:bg-red-500"
          >
            <Siren className="size-4" aria-hidden="true" />
            <span className="sr-only sm:not-sr-only">Emergency</span>
          </button>
        )}
      </div>
    </header>
  )
}
