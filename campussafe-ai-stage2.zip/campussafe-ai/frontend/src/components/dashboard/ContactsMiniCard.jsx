import { ChevronRight, Phone } from 'lucide-react'
import { Link } from 'react-router-dom'
import { EMERGENCY_CONTACTS } from '../../data/contacts.js'
import ContactCard from '../ContactCard.jsx'

const DASHBOARD_CONTACT_IDS = ['emergency-112', 'ambulance', 'campus-security']

/** Short contact list for the dashboard, linking to the full contacts page. */
export default function ContactsMiniCard() {
  return (
    <section aria-labelledby="contacts-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
      <div className="flex items-center gap-2">
        <Phone className="size-5 text-teal-300" aria-hidden="true" />
        <h2 id="contacts-heading" className="font-display text-lg font-semibold text-white">
          Emergency contacts
        </h2>
      </div>
      <div className="mt-2 divide-y divide-white/5">
        {EMERGENCY_CONTACTS.filter((contact) => DASHBOARD_CONTACT_IDS.includes(contact.id)).map((contact) => (
          <ContactCard key={contact.id} contact={contact} compact />
        ))}
      </div>
      <Link
        to="/contacts"
        className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-teal-300 transition-colors hover:text-teal-200"
      >
        All contacts and what to say when you call
        <ChevronRight className="size-4" aria-hidden="true" />
      </Link>
    </section>
  )
}
