import { Footprints, ListOrdered } from 'lucide-react'
import { useEmergency } from '../../context/EmergencyContext.jsx'

/** Turn-by-turn directions. Filled in by the routing engine in Stage 3. */
export default function NavigationStepsPanel() {
  const { selectedLocation, selectedEmergency } = useEmergency()
  const ready = Boolean(selectedLocation && selectedEmergency)

  return (
    <section aria-labelledby="steps-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
      <div className="flex items-center gap-2">
        <ListOrdered className="size-5 text-teal-300" aria-hidden="true" />
        <h2 id="steps-heading" className="font-display text-lg font-semibold text-white">
          Step-by-step directions
        </h2>
      </div>

      <div className="mt-4 flex flex-col items-center rounded-xl border border-dashed border-white/15 px-4 py-10 text-center">
        <Footprints className="size-8 text-slate-500" aria-hidden="true" />
        <p className="mt-3 text-sm font-medium text-slate-200">
          {ready ? 'Selections ready for routing' : 'Choose your location and emergency type'}
        </p>
        <p className="mt-1 max-w-xs text-xs leading-relaxed text-slate-400">
          Directions such as "Leave by the east door, then follow the main avenue north" will appear here once the
          routing engine is added in Stage 3.
        </p>
      </div>
    </section>
  )
}
