import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { LocateFixed, MapPinned } from 'lucide-react'
import { useCampus } from '../../context/CampusContext.jsx'
import { useEmergency } from '../../context/EmergencyContext.jsx'
import { useGeolocation } from '../../hooks/useGeolocation.js'
import { describeCampusData, getEligibleDestinations, START_KINDS } from '../../utils/campus.js'
import { findNearestPlace, formatDistance } from '../../utils/geo.js'
import CampusMap from '../map/CampusMap.jsx'

// Only suggest a building from GPS when the fix is good and the building is close.
const MAX_ACCURACY_M = 50
const MAX_SUGGEST_DISTANCE_M = 80

function EmptyCampus({ campusName, onTryDemo }) {
  return (
    <section className="rounded-3xl border border-dashed border-white/20 bg-navy-900 p-6 text-center sm:p-10">
      <MapPinned className="mx-auto size-10 text-teal-300" aria-hidden="true" />
      <h2 className="mt-4 font-display text-2xl font-semibold text-white">{campusName} isn’t mapped yet</h2>
      <p className="mx-auto mt-2 max-w-md text-slate-400">
        Walk the campus and mark buildings, walkways and official assembly points in the campus mapper. Your data is
        saved on this device.
      </p>
      <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
        <Link to="/mapper" className="rounded-xl bg-teal-400 px-5 py-2.5 font-semibold text-navy-950 transition-colors hover:bg-teal-300">
          Start mapping
        </Link>
        <button
          type="button"
          onClick={onTryDemo}
          className="rounded-xl border border-white/15 px-5 py-2.5 font-semibold text-white transition-colors hover:border-white/30"
        >
          Try the demo campus
        </button>
      </div>
    </section>
  )
}

/** Dashboard map: tap a building to set your location; optional GPS help outdoors. */
export default function DashboardMap() {
  const { campus, setActiveCampusId } = useCampus()
  const { locationId, setLocationId, selectedEmergency } = useEmergency()
  const geo = useGeolocation()
  const [flyTarget, setFlyTarget] = useState(null)
  const isSimple = campus.crs === 'simple'

  const destinationIds = useMemo(
    () => getEligibleDestinations(campus, selectedEmergency?.id).map((place) => place.id),
    [campus, selectedEmergency],
  )

  useEffect(() => {
    if (geo.position) setFlyTarget(geo.position)
  }, [geo.position])

  if (campus.places.length === 0) {
    return <EmptyCampus campusName={campus.shortName} onTryDemo={() => setActiveCampusId('demo')} />
  }

  const nearest = geo.position && !isSimple ? findNearestPlace(campus, geo.position, START_KINDS) : null
  const canSuggest =
    nearest &&
    geo.position.accuracy <= MAX_ACCURACY_M &&
    nearest.distance <= MAX_SUGGEST_DISTANCE_M &&
    nearest.place.id !== locationId
  const stats = describeCampusData(campus)

  return (
    <section aria-labelledby="map-heading" className="rounded-3xl border border-white/10 bg-navy-900 p-3 sm:p-4">
      <div className="flex flex-wrap items-start justify-between gap-3 px-2 pb-3 pt-1">
        <div>
          <h2 id="map-heading" className="font-display text-lg font-semibold text-white">
            Campus map
          </h2>
          <p className="text-sm text-slate-400">Tap a building to set where you are.</p>
        </div>
        <span className="rounded-full border border-caution/40 bg-caution/10 px-3 py-1 text-xs font-medium text-amber-100">
          {campus.isFictional ? 'Fictional campus' : `Your survey: ${stats.unverified} unverified`}
        </span>
      </div>

      <CampusMap
        campus={campus}
        className="h-[380px] sm:h-[460px]"
        selectedPlaceId={locationId}
        highlightedPlaceIds={destinationIds}
        userPosition={geo.position}
        flyToTarget={flyTarget}
        onPlaceClick={(place) => {
          if (START_KINDS.includes(place.kind)) setLocationId(place.id)
        }}
      />

      <div className="flex flex-col gap-3 px-2 pt-4 sm:flex-row sm:items-start">
        {!isSimple && (
          <button
            type="button"
            onClick={geo.locate}
            disabled={geo.status === 'locating'}
            className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl border border-white/15 px-4 py-2 text-sm font-semibold text-white transition-colors hover:border-white/30 disabled:opacity-60"
          >
            <LocateFixed className="size-4" aria-hidden="true" />
            {geo.status === 'locating' ? 'Finding you…' : 'Show my GPS position'}
          </button>
        )}
        <div role="status" className="text-sm text-slate-400">
          {isSimple && 'GPS is not available on the demo campus because it is fictional.'}
          {!isSimple && geo.status === 'idle' && 'GPS works outdoors only. Always confirm your building yourself.'}
          {geo.status === 'error' && <span className="text-caution">{geo.error}</span>}
          {geo.status === 'ready' && (
            <span>
              GPS accuracy about {geo.position.accuracy} m.
              {geo.position.accuracy > MAX_ACCURACY_M && ' Too rough to pick a building, so choose it yourself.'}
            </span>
          )}
          {canSuggest && (
            <span className="mt-2 flex flex-wrap items-center gap-2 text-slate-200">
              Closest mapped place: {nearest.place.name} ({formatDistance(nearest.distance)}).
              <button
                type="button"
                onClick={() => setLocationId(nearest.place.id)}
                className="rounded-lg bg-teal-400 px-3 py-1 text-sm font-semibold text-navy-950 hover:bg-teal-300"
              >
                Use {nearest.place.name}
              </button>
            </span>
          )}
        </div>
      </div>

      <ul className="flex flex-wrap gap-x-5 gap-y-2 px-2 pb-1 pt-4 text-xs text-slate-400" aria-label="Map legend">
        <li className="inline-flex items-center gap-1.5">
          <span className="size-2.5 rounded-sm bg-danger" aria-hidden="true" /> You are here
        </li>
        <li className="inline-flex items-center gap-1.5">
          <span className="size-2.5 rounded-sm bg-safe" aria-hidden="true" /> Suitable destination
        </li>
        <li className="inline-flex items-center gap-1.5">
          <span className="h-1 w-4 rounded-full bg-teal-400" aria-hidden="true" /> Step-free walkway
        </li>
        <li className="inline-flex items-center gap-1.5">
          <span className="h-1 w-4 rounded-full bg-slate-400" aria-hidden="true" /> Walkway with steps
        </li>
        {!campus.isFictional && <li>Dashed lines and outlines: not yet verified on site</li>}
      </ul>
    </section>
  )
}
