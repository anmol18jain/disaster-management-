import { Accessibility } from 'lucide-react'
import { useEmergency } from '../../context/EmergencyContext.jsx'
import EmergencyTypeSelector from '../EmergencyTypeSelector.jsx'
import LocationSelector from '../LocationSelector.jsx'

/** "Your situation": where you are, what is happening, and whether you need a step-free route. */
export default function SelectionPanel() {
  const {
    locationId,
    setLocationId,
    emergencyTypeId,
    setEmergencyTypeId,
    needsStepFree,
    setNeedsStepFree,
  } = useEmergency()

  return (
    <section aria-labelledby="situation-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
      <h2 id="situation-heading" className="font-display text-lg font-semibold text-white">
        Your situation
      </h2>

      <div className="mt-4 grid gap-5 md:grid-cols-[minmax(0,1fr)_minmax(0,1.5fr)]">
        <LocationSelector value={locationId} onChange={setLocationId} />
        <EmergencyTypeSelector value={emergencyTypeId} onChange={setEmergencyTypeId} name="dashboard-emergency-type" />
      </div>

      <div className="mt-5 flex items-start justify-between gap-4 rounded-xl bg-navy-850 p-4">
        <div className="flex gap-3">
          <Accessibility className="mt-0.5 size-5 shrink-0 text-teal-300" aria-hidden="true" />
          <div>
            <p id="step-free-label" className="text-sm font-medium text-white">
              I need a step-free route
            </p>
            <p id="step-free-help" className="mt-1 text-xs leading-relaxed text-slate-400">
              Routes will avoid stairs and steps (Stage 3). In a fire, elevators are not used unless personnel direct it,
              so follow your personal evacuation plan or wait at a refuge point for help.
            </p>
          </div>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={needsStepFree}
          aria-labelledby="step-free-label"
          aria-describedby="step-free-help"
          onClick={() => setNeedsStepFree(!needsStepFree)}
          className={`relative mt-0.5 inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
            needsStepFree ? 'bg-teal-400' : 'bg-white/15'
          }`}
        >
          <span
            className={`inline-block size-5 rounded-full bg-white shadow transition-transform ${
              needsStepFree ? 'translate-x-5' : 'translate-x-0.5'
            }`}
          />
        </button>
      </div>
    </section>
  )
}
