import { Map as MapIcon, MapPin, ShieldCheck, Siren, WifiOff } from 'lucide-react'
import { useCampus } from '../../context/CampusContext.jsx'
import { useEmergency } from '../../context/EmergencyContext.jsx'
import { describeCampusData } from '../../utils/campus.js'

const TONE_CLASSES = {
  safe: 'text-safe',
  danger: 'text-danger',
  caution: 'text-caution',
}

/**
 * Honest status: what the app knows and what it does NOT know.
 * It never claims live monitoring, because no live data source is connected.
 */
export default function CampusStatusCard() {
  const { emergencyMode } = useEmergency()
  const { campus } = useCampus()
  const stats = describeCampusData(campus)

  const rows = [
    {
      icon: emergencyMode ? Siren : ShieldCheck,
      label: 'Campus status',
      value: emergencyMode ? 'Emergency (simulated)' : 'Normal (simulated)',
      tone: emergencyMode ? 'danger' : 'safe',
    },
    {
      icon: WifiOff,
      label: 'Live hazard data',
      value: 'Not connected',
      note: 'Any hazards in this demo are simulated.',
      tone: 'caution',
    },
    {
      icon: MapPin,
      label: 'Your location',
      value: 'Chosen manually',
      note: 'GPS is not used inside buildings.',
      tone: 'caution',
    },
    {
      icon: MapIcon,
      label: 'Map data',
      value: campus.isFictional ? 'Fictional campus' : `${stats.mapped} places mapped`,
      note: campus.isFictional
        ? 'Not a real place.'
        : `Your own survey, ${stats.unverified} items not verified. Not approved by campus safety staff.`,
      tone: 'caution',
    },
  ]

  return (
    <section aria-labelledby="status-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
      <h2 id="status-heading" className="font-display text-lg font-semibold text-white">
        System status
      </h2>
      <ul className="mt-3 divide-y divide-white/5">
        {rows.map(({ icon: Icon, label, value, note, tone }) => (
          <li key={label} className="flex gap-3 py-3">
            <Icon className={`mt-0.5 size-4 shrink-0 ${TONE_CLASSES[tone]}`} aria-hidden="true" />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                <span className="text-sm text-slate-400">{label}</span>
                <span className="text-sm font-semibold text-white">{value}</span>
              </div>
              {note && <p className="mt-0.5 text-xs text-slate-500">{note}</p>}
            </div>
          </li>
        ))}
      </ul>
    </section>
  )
}
