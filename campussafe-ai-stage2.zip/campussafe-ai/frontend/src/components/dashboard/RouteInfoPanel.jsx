import { Info, Route } from 'lucide-react'
import { useCampus } from '../../context/CampusContext.jsx'
import { useEmergency } from '../../context/EmergencyContext.jsx'
import { getEligibleDestinations } from '../../utils/campus.js'
import DestinationList from '../DestinationList.jsx'

function NotCalculated() {
  return (
    <>
      <span aria-hidden="true">—</span>
      <span className="sr-only">Not calculated yet</span>
    </>
  )
}

/**
 * Route summary. In Stage 1 it shows the selections and the allowed destinations.
 * Distance, time and the recommended destination come from the routing engine in Stage 3.
 */
export default function RouteInfoPanel() {
  const { campus } = useCampus()
  const { selectedLocation, selectedEmergency } = useEmergency()
  const destinations = getEligibleDestinations(campus, selectedEmergency?.id)

  return (
    <section aria-labelledby="route-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
      <div className="flex items-center gap-2">
        <Route className="size-5 text-teal-300" aria-hidden="true" />
        <h2 id="route-heading" className="font-display text-lg font-semibold text-white">
          Route
        </h2>
      </div>

      <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-4">
        <div>
          <dt className="text-xs text-slate-400">From</dt>
          <dd className={`mt-0.5 text-sm font-medium ${selectedLocation ? 'text-white' : 'text-slate-500'}`}>
            {selectedLocation?.name ?? 'Not selected'}
          </dd>
        </div>
        <div>
          <dt className="text-xs text-slate-400">Emergency</dt>
          <dd className={`mt-0.5 text-sm font-medium ${selectedEmergency ? 'text-white' : 'text-slate-500'}`}>
            {selectedEmergency?.label ?? 'Not selected'}
          </dd>
        </div>
        <div>
          <dt className="text-xs text-slate-400">Distance</dt>
          <dd className="mt-0.5 font-display text-2xl font-semibold text-slate-500">
            <NotCalculated />
          </dd>
        </div>
        <div>
          <dt className="text-xs text-slate-400">Walking time</dt>
          <dd className="mt-0.5 font-display text-2xl font-semibold text-slate-500">
            <NotCalculated />
          </dd>
        </div>
      </dl>

      <div className="mt-5 border-t border-white/10 pt-4">
        <h3 className="text-sm font-semibold text-white">Suitable destinations</h3>
        {selectedEmergency ? (
          <DestinationList destinations={destinations} />
        ) : (
          <p className="mt-1 text-sm text-slate-400">Choose an emergency type to see where people should go.</p>
        )}
      </div>

      <p className="mt-4 flex gap-2 text-xs leading-relaxed text-slate-400">
        <Info className="size-4 shrink-0" aria-hidden="true" />
        No route is recommended yet. The routing engine is added in Stage 3, and until then the app will not suggest a path.
      </p>
    </section>
  )
}
