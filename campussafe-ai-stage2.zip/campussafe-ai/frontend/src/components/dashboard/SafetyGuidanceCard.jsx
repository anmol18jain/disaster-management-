import { BookOpen, ChevronRight, TriangleAlert } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useEmergency } from '../../context/EmergencyContext.jsx'
import EmergencyIcon from '../EmergencyIcon.jsx'

/** What to do for the selected emergency type. */
export default function SafetyGuidanceCard() {
  const { selectedEmergency } = useEmergency()

  return (
    <section aria-labelledby="guidance-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
      <div className="flex items-center gap-2">
        {selectedEmergency ? (
          <EmergencyIcon typeId={selectedEmergency.id} className="size-5 text-teal-300" />
        ) : (
          <BookOpen className="size-5 text-teal-300" aria-hidden="true" />
        )}
        <h2 id="guidance-heading" className="font-display text-lg font-semibold text-white">
          {selectedEmergency ? `${selectedEmergency.label}: what to do` : 'Safety guidance'}
        </h2>
      </div>

      {!selectedEmergency && (
        <p className="mt-3 text-sm text-slate-400">Choose an emergency type to see what to do and how routes are restricted.</p>
      )}

      {selectedEmergency && (
        <>
          {selectedEmergency.requiresOfficialDecision && (
            <div role="note" className="mt-4 flex gap-3 rounded-xl border border-caution/40 bg-caution/10 p-3.5">
              <TriangleAlert className="mt-0.5 size-4 shrink-0 text-caution" aria-hidden="true" />
              <p className="text-sm text-amber-50">
                <strong className="font-semibold">Wait for official instruction.</strong> {selectedEmergency.officialDecisionNote}
              </p>
            </div>
          )}

          <ol className="mt-4 list-decimal space-y-2 pl-5 text-sm leading-relaxed text-slate-300 marker:text-slate-500">
            {selectedEmergency.instructions.map((step) => (
              <li key={step}>{step}</li>
            ))}
          </ol>

          <h3 className="mt-5 text-sm font-semibold text-white">How routes are restricted</h3>
          <ul className="mt-2 space-y-1.5 text-sm text-slate-400">
            {selectedEmergency.routeRules.map((rule) => (
              <li key={rule} className="flex gap-2">
                <span className="mt-2 size-1.5 shrink-0 rounded-full bg-teal-300" aria-hidden="true" />
                {rule}
              </li>
            ))}
          </ul>
        </>
      )}

      <Link
        to="/guide"
        className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-teal-300 transition-colors hover:text-teal-200"
      >
        Survival guide: trapped, burns, CPR and more
        <ChevronRight className="size-4" aria-hidden="true" />
      </Link>
      <p className="mt-4 border-t border-white/10 pt-3 text-xs text-slate-500">
        General guidance only. Your university's official procedures and emergency personnel take priority.
      </p>
    </section>
  )
}
