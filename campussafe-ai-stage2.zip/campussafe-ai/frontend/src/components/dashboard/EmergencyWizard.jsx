import { useEffect, useRef, useState } from 'react'
import { Info, TriangleAlert, X } from 'lucide-react'
import { useCampus } from '../../context/CampusContext.jsx'
import { useEmergency } from '../../context/EmergencyContext.jsx'
import { getEligibleDestinations } from '../../utils/campus.js'
import DestinationList from '../DestinationList.jsx'
import EmergencyIcon from '../EmergencyIcon.jsx'
import EmergencyTypeSelector from '../EmergencyTypeSelector.jsx'
import LocationSelector from '../LocationSelector.jsx'

const STEPS = ['Your location', 'Emergency type', 'Review']

/**
 * The "Start emergency navigation" dialog.
 * Step 1: where are you?  Step 2: what is happening?  Step 3: review guidance.
 * In Stage 3, step 3 will also show the calculated route.
 */
export default function EmergencyWizard() {
  const {
    locationId,
    setLocationId,
    emergencyTypeId,
    setEmergencyTypeId,
    selectedLocation,
    selectedEmergency,
    closeWizard,
  } = useEmergency()
  const [step, setStep] = useState(0)
  const dialogRef = useRef(null)

  // When the dialog opens: move keyboard focus into it, stop the page behind
  // from scrolling, and let Escape close it. Undo all of that when it closes.
  useEffect(() => {
    dialogRef.current?.focus()
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'

    const handleKey = (event) => {
      if (event.key === 'Escape') closeWizard()
    }
    window.addEventListener('keydown', handleKey)

    return () => {
      window.removeEventListener('keydown', handleKey)
      document.body.style.overflow = previousOverflow
    }
  }, [closeWizard])

  const canContinue = (step === 0 && Boolean(locationId)) || (step === 1 && Boolean(emergencyTypeId))
  const isLastStep = step === STEPS.length - 1

  return (
    <div
      className="fixed inset-0 z-[60] flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-6"
      onMouseDown={(event) => {
        // Clicking the dark area outside the dialog closes it.
        if (event.target === event.currentTarget) closeWizard()
      }}
    >
      <div
        ref={dialogRef}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-labelledby="wizard-title"
        className="flex max-h-[92dvh] w-full max-w-2xl animate-sheet-in flex-col overflow-hidden rounded-t-3xl border border-white/10 bg-navy-900 shadow-2xl shadow-black/50 focus:outline-none sm:rounded-3xl"
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-white/10 px-5 py-4 sm:px-6">
          <div>
            <p className="text-sm font-medium text-red-300">Emergency navigation (simulation)</p>
            <h2 id="wizard-title" className="font-display text-2xl font-bold text-white">
              {STEPS[step]}
            </h2>
          </div>
          <button
            type="button"
            onClick={closeWizard}
            className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-white/5 hover:text-white"
            aria-label="Close emergency navigation"
          >
            <X className="size-5" aria-hidden="true" />
          </button>
        </div>

        {/* Progress */}
        <ol className="flex gap-2 px-5 pt-4 sm:px-6" aria-label="Progress">
          {STEPS.map((label, index) => (
            <li key={label} className="flex-1" aria-current={index === step ? 'step' : undefined}>
              <span
                className={`block h-1.5 rounded-full transition-colors ${index <= step ? 'bg-teal-400' : 'bg-white/10'}`}
                aria-hidden="true"
              />
              <span className={`mt-1.5 block text-xs ${index === step ? 'text-white' : 'text-slate-500'}`}>
                {index + 1}. {label}
              </span>
            </li>
          ))}
        </ol>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-5 py-5 sm:px-6">
          {step === 0 && (
            <LocationSelector variant="cards" name="wizard-location" value={locationId} onChange={setLocationId} />
          )}

          {step === 1 && (
            <EmergencyTypeSelector
              size="large"
              name="wizard-emergency-type"
              value={emergencyTypeId}
              onChange={setEmergencyTypeId}
            />
          )}

          {step === 2 && <ReviewStep location={selectedLocation} emergency={selectedEmergency} />}
        </div>

        {/* Footer buttons */}
        <div className="flex items-center justify-between gap-3 border-t border-white/10 px-5 py-4 sm:px-6">
          <button
            type="button"
            onClick={() => (step === 0 ? closeWizard() : setStep(step - 1))}
            className="rounded-xl px-4 py-2.5 text-sm font-semibold text-slate-300 transition-colors hover:bg-white/5 hover:text-white"
          >
            {step === 0 ? 'Cancel' : 'Back'}
          </button>

          {isLastStep ? (
            <button
              type="button"
              onClick={closeWizard}
              className="rounded-xl bg-teal-400 px-5 py-2.5 text-sm font-semibold text-navy-950 transition-colors hover:bg-teal-300"
            >
              View on dashboard
            </button>
          ) : (
            <div className="flex items-center gap-3">
              {!canContinue && (
                <span className="hidden text-xs text-slate-500 sm:inline">
                  {step === 0 ? 'Choose a location to continue' : 'Choose an emergency type to continue'}
                </span>
              )}
              <button
                type="button"
                onClick={() => setStep(step + 1)}
                disabled={!canContinue}
                className="rounded-xl bg-teal-400 px-5 py-2.5 text-sm font-semibold text-navy-950 transition-colors hover:bg-teal-300 disabled:cursor-not-allowed disabled:bg-white/10 disabled:text-slate-500"
              >
                Continue
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/** Step 3: summary, allowed destinations and what to do. */
function ReviewStep({ location, emergency }) {
  const { campus } = useCampus()
  if (!location || !emergency) {
    return <p className="text-sm text-caution">Go back and choose both a location and an emergency type.</p>
  }

  const destinations = getEligibleDestinations(campus, emergency.id)

  return (
    <div className="space-y-6">
      <dl className="grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl bg-navy-850 p-4">
          <dt className="text-xs text-slate-400">Starting point</dt>
          <dd className="mt-1 font-semibold text-white">{location.name}</dd>
        </div>
        <div className="rounded-xl bg-navy-850 p-4">
          <dt className="text-xs text-slate-400">Emergency</dt>
          <dd className="mt-1 flex items-center gap-2 font-semibold text-white">
            <EmergencyIcon typeId={emergency.id} className="size-4 text-teal-300" />
            {emergency.label}
          </dd>
        </div>
      </dl>

      {emergency.requiresOfficialDecision && (
        <div role="note" className="flex gap-3 rounded-xl border border-caution/40 bg-caution/10 p-4">
          <TriangleAlert className="mt-0.5 size-5 shrink-0 text-caution" aria-hidden="true" />
          <p className="text-sm text-amber-50">
            <strong className="font-semibold">Wait for official instruction.</strong> {emergency.officialDecisionNote}
          </p>
        </div>
      )}

      <div>
        <h3 className="font-display text-lg font-semibold text-white">Suitable destinations</h3>
        <DestinationList destinations={destinations} />
      </div>

      <div>
        <h3 className="font-display text-lg font-semibold text-white">What to do</h3>
        <ol className="mt-2 list-decimal space-y-2 pl-5 text-sm leading-relaxed text-slate-300 marker:text-slate-500">
          {emergency.instructions.map((instruction) => (
            <li key={instruction}>{instruction}</li>
          ))}
        </ol>
      </div>

      <p className="flex gap-3 rounded-xl bg-white/5 p-4 text-sm text-slate-300">
        <Info className="mt-0.5 size-4 shrink-0 text-teal-300" aria-hidden="true" />
        Route calculation is added in Stage 3. Until then, CampusSafe AI will not suggest a path. Follow exit signs and
        emergency personnel.
      </p>
    </div>
  )
}
