import { Activity, Flame, FlaskConical, Mountain, Siren, Waves } from 'lucide-react'

const ICONS = {
  fire: Flame,
  earthquake: Activity,
  flood: Waves,
  chemical: FlaskConical,
  landslide: Mountain,
  general: Siren,
}

/** Icon for an emergency type, e.g. <EmergencyIcon typeId="fire" />. */
export default function EmergencyIcon({ typeId, className = 'size-5' }) {
  const Icon = ICONS[typeId] ?? Siren
  return <Icon className={className} aria-hidden="true" />
}

/*
  Colour used when an emergency type is selected.
  Tailwind needs full class names written out, so they are listed here
  rather than built from strings like `bg-${color}-500`.
*/
export const EMERGENCY_SELECTED_STYLES = {
  fire: 'border-red-400/70 bg-red-500/15 text-red-100',
  earthquake: 'border-orange-400/70 bg-orange-500/15 text-orange-100',
  flood: 'border-sky-400/70 bg-sky-500/15 text-sky-100',
  chemical: 'border-yellow-300/70 bg-yellow-400/15 text-yellow-100',
  landslide: 'border-amber-500/70 bg-amber-700/20 text-amber-100',
  general: 'border-teal-300/70 bg-teal-400/15 text-teal-100',
}
