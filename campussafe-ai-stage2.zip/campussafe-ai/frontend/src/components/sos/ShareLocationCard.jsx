import { useState } from 'react'
import { LocateFixed, MapPin } from 'lucide-react'
import { useCampus } from '../../context/CampusContext.jsx'
import { useEmergency } from '../../context/EmergencyContext.jsx'
import { useGeolocation } from '../../hooks/useGeolocation.js'
import { buildHelpMessage } from '../../utils/messages.js'
import ShareButtons from '../ShareButtons.jsx'

/** Builds a help message with your building, floor/room and GPS, ready to send. */
export default function ShareLocationCard() {
  const { campus } = useCampus()
  const { selectedLocation } = useEmergency()
  const geo = useGeolocation()
  const [details, setDetails] = useState('')

  const message = buildHelpMessage({
    campusName: campus.name,
    placeName: selectedLocation?.name,
    details,
    position: geo.position,
  })

  return (
    <section aria-labelledby="share-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
      <div className="flex items-center gap-2">
        <MapPin className="size-5 text-danger" aria-hidden="true" />
        <h2 id="share-heading" className="font-display text-lg font-semibold text-white">
          Ask for help with your location
        </h2>
      </div>
      <p className="mt-2 text-sm text-slate-400">
        {selectedLocation ? `Building: ${selectedLocation.name}. ` : 'Tip: set your building on the dashboard first. '}
        The floor and room matter most, because GPS can’t tell which floor you’re on.
      </p>

      <label htmlFor="help-details" className="mt-4 block text-sm font-medium text-slate-300">
        Floor, room or landmark
      </label>
      <input
        id="help-details"
        value={details}
        onChange={(event) => setDetails(event.target.value)}
        maxLength={120}
        placeholder="e.g. 3rd floor, room 305, trapped, 2 people"
        className="mt-1.5 w-full rounded-lg border border-white/15 bg-navy-850 px-3 py-2 text-sm text-white placeholder:text-slate-500"
      />

      <button
        type="button"
        onClick={geo.locate}
        disabled={geo.status === 'locating'}
        className="mt-3 inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-2 text-sm font-semibold text-white hover:border-white/30 disabled:opacity-60"
      >
        <LocateFixed className="size-4" aria-hidden="true" />
        {geo.status === 'locating' ? 'Finding you…' : geo.position ? 'Update GPS position' : 'Add GPS position'}
      </button>
      {geo.status === 'error' && <p className="mt-2 text-sm text-caution">{geo.error}</p>}

      <label htmlFor="help-message" className="mt-4 block text-sm font-medium text-slate-300">
        Message
      </label>
      <textarea id="help-message" readOnly rows={5} value={message} className="mt-1.5 w-full rounded-lg border border-white/10 bg-navy-950 p-3 text-sm text-slate-200" />
      <div className="mt-3">
        <ShareButtons message={message} title="I need help" />
      </div>
    </section>
  )
}
