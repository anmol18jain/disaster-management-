import { Volume2, VolumeX } from 'lucide-react'
import { useSosSound } from '../../hooks/useSosSound.js'

/** Plays a loud repeating SOS so rescuers can find you without you shouting. */
export default function SosSoundCard() {
  const { playing, start, stop, supported } = useSosSound()

  return (
    <section aria-labelledby="sound-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
      <div className="flex items-center gap-2">
        <Volume2 className="size-5 text-caution" aria-hidden="true" />
        <h2 id="sound-heading" className="font-display text-lg font-semibold text-white">
          SOS sound
        </h2>
      </div>
      <p className="mt-2 text-sm text-slate-400">
        A high-pitched SOS signal (... --- ...) on repeat. It saves your voice and breath if you are trapped. Turn the volume
        up; silent mode may mute it. Keep it away from your ear.
      </p>
      {supported ? (
        <button
          type="button"
          onClick={playing ? stop : start}
          aria-pressed={playing}
          className={`mt-4 inline-flex items-center gap-2 rounded-xl px-5 py-2.5 font-semibold ${
            playing ? 'bg-danger text-white hover:bg-red-500' : 'bg-caution text-navy-950 hover:bg-amber-300'
          }`}
        >
          {playing ? <VolumeX className="size-5" aria-hidden="true" /> : <Volume2 className="size-5" aria-hidden="true" />}
          {playing ? 'Stop SOS sound' : 'Play SOS sound'}
        </button>
      ) : (
        <p className="mt-4 text-sm text-caution">This browser can’t play sounds.</p>
      )}
    </section>
  )
}
