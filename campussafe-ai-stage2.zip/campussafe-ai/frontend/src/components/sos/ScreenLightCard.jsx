import { useCallback, useEffect, useRef, useState } from 'react'
import { Lightbulb } from 'lucide-react'

/**
 * Turns the whole screen bright white: a torch for dark corridors, or a signal
 * from a window. It is a steady light on purpose: flashing lights can trigger seizures.
 */
export default function ScreenLightCard() {
  const [on, setOn] = useState(false)
  const wakeLockRef = useRef(null)

  const turnOff = useCallback(() => {
    setOn(false)
    if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {})
    wakeLockRef.current?.release?.().catch(() => {})
    wakeLockRef.current = null
  }, [])

  async function turnOn() {
    setOn(true)
    try {
      await document.documentElement.requestFullscreen?.()
    } catch {
      // Fullscreen isn't available everywhere; the white overlay still works.
    }
    try {
      // Stops the screen from switching off while the light is on (where supported).
      wakeLockRef.current = (await navigator.wakeLock?.request('screen')) ?? null
    } catch {
      wakeLockRef.current = null
    }
  }

  useEffect(() => {
    if (!on) return undefined
    const handleKey = (event) => {
      if (event.key === 'Escape') turnOff()
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [on, turnOff])

  useEffect(() => () => wakeLockRef.current?.release?.().catch(() => {}), [])

  return (
    <section aria-labelledby="light-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
      <div className="flex items-center gap-2">
        <Lightbulb className="size-5 text-caution" aria-hidden="true" />
        <h2 id="light-heading" className="font-display text-lg font-semibold text-white">
          Screen light
        </h2>
      </div>
      <p className="mt-2 text-sm text-slate-400">
        Fills the screen with white light. Turn your brightness up. Use it to see in a dark corridor or to signal from a window.
      </p>
      <button type="button" onClick={turnOn} className="mt-4 rounded-xl bg-white px-5 py-2.5 font-semibold text-navy-950 hover:bg-slate-200">
        Turn on light
      </button>

      {on && (
        <div role="dialog" aria-modal="true" aria-label="Screen light" className="fixed inset-0 z-[100] grid place-items-center bg-white">
          <button
            type="button"
            onClick={turnOff}
            autoFocus
            className="rounded-2xl border-2 border-slate-300 px-8 py-4 text-lg font-semibold text-slate-700"
          >
            Turn off light
          </button>
        </div>
      )}
    </section>
  )
}
