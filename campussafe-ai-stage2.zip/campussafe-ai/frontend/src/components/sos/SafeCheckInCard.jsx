import { useState } from 'react'
import { ShieldCheck } from 'lucide-react'
import { useCampus } from '../../context/CampusContext.jsx'
import { buildSafeMessage } from '../../utils/messages.js'
import ShareButtons from '../ShareButtons.jsx'

/** "I'm safe" message for family, friends or your class group, so they stop calling and the lines stay free. */
export default function SafeCheckInCard() {
  const { campus } = useCampus()
  const safePlaces = campus.places.filter((place) => ['assembly', 'refuge', 'gate'].includes(place.kind))
  const [placeName, setPlaceName] = useState('')
  const [note, setNote] = useState('')
  const message = buildSafeMessage({ campusName: campus.name, placeName, note })

  return (
    <section aria-labelledby="safe-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
      <div className="flex items-center gap-2">
        <ShieldCheck className="size-5 text-safe" aria-hidden="true" />
        <h2 id="safe-heading" className="font-display text-lg font-semibold text-white">
          Tell people you’re safe
        </h2>
      </div>
      <p className="mt-2 text-sm text-slate-400">A quick message keeps phone lines free for people who need help.</p>

      <label htmlFor="safe-place" className="mt-4 block text-sm font-medium text-slate-300">
        Where are you now?
      </label>
      <input
        id="safe-place"
        list="safe-place-options"
        value={placeName}
        onChange={(event) => setPlaceName(event.target.value)}
        maxLength={80}
        placeholder="Assembly point, hostel, off campus…"
        className="mt-1.5 w-full rounded-lg border border-white/15 bg-navy-850 px-3 py-2 text-sm text-white placeholder:text-slate-500"
      />
      <datalist id="safe-place-options">
        {safePlaces.map((place) => (
          <option key={place.id} value={place.name} />
        ))}
      </datalist>

      <label htmlFor="safe-note" className="mt-3 block text-sm font-medium text-slate-300">
        Note <span className="font-normal text-slate-500">(optional)</span>
      </label>
      <input
        id="safe-note"
        value={note}
        onChange={(event) => setNote(event.target.value)}
        maxLength={120}
        placeholder="e.g. My roommate is with me."
        className="mt-1.5 w-full rounded-lg border border-white/15 bg-navy-850 px-3 py-2 text-sm text-white placeholder:text-slate-500"
      />

      <p className="mt-4 whitespace-pre-line rounded-lg bg-navy-950 p-3 text-sm text-slate-200">{message}</p>
      <div className="mt-3">
        <ShareButtons message={message} title="I'm safe" />
      </div>
    </section>
  )
}
