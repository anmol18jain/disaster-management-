import { useEffect, useState } from 'react'
import { HeartPulse } from 'lucide-react'
import { readJson, removeKey, writeJson } from '../../utils/storage.js'

const STORAGE_KEY = 'campussafe:v1:medical-card'
const EMPTY = { name: '', bloodGroup: '', allergies: '', conditions: '', medications: '', contactName: '', contactPhone: '' }
const BLOOD_GROUPS = ['', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Not sure']
const FIELDS = [
  { id: 'name', label: 'Name', max: 60 },
  { id: 'allergies', label: 'Allergies', max: 120, placeholder: 'e.g. penicillin, peanuts' },
  { id: 'conditions', label: 'Medical conditions', max: 120, placeholder: 'e.g. asthma, diabetes, epilepsy' },
  { id: 'medications', label: 'Regular medicines', max: 120 },
  { id: 'contactName', label: 'Emergency contact name', max: 60 },
  { id: 'contactPhone', label: 'Emergency contact phone', max: 20, type: 'tel' },
]

/**
 * Optional medical card a responder can read from your phone.
 * Stored only in this browser on this device. Nothing is uploaded.
 */
export default function MedicalCard() {
  const [card, setCard] = useState(() => ({ ...EMPTY, ...(readJson(STORAGE_KEY) ?? {}) }))
  const [hasSaved, setHasSaved] = useState(() => readJson(STORAGE_KEY) !== null)
  const [showing, setShowing] = useState(false)
  const [status, setStatus] = useState('')

  useEffect(() => {
    if (!showing) return undefined
    const handleKey = (event) => {
      if (event.key === 'Escape') setShowing(false)
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [showing])

  function update(field, value) {
    setCard((current) => ({ ...current, [field]: value }))
  }

  function save(event) {
    event.preventDefault()
    const saved = writeJson(STORAGE_KEY, card)
    setHasSaved(saved)
    setStatus(saved ? 'Saved on this device.' : 'Could not save: storage is blocked in this browser.')
  }

  function remove() {
    removeKey(STORAGE_KEY)
    setCard(EMPTY)
    setHasSaved(false)
    setStatus('Medical card deleted from this device.')
  }

  const inputClass = 'mt-1 w-full rounded-lg border border-white/15 bg-navy-850 px-3 py-2 text-sm text-white placeholder:text-slate-500'

  return (
    <section aria-labelledby="medical-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
      <div className="flex items-center gap-2">
        <HeartPulse className="size-5 text-danger" aria-hidden="true" />
        <h2 id="medical-heading" className="font-display text-lg font-semibold text-white">
          Medical card
        </h2>
      </div>
      <p className="mt-2 text-sm text-slate-400">
        Optional. Helps responders if you can’t speak. It stays only on this device, but anyone using your unlocked phone can read it.
      </p>

      <form onSubmit={save} className="mt-4 grid gap-3 sm:grid-cols-2">
        {FIELDS.slice(0, 1).map((field) => (
          <label key={field.id} className="text-sm text-slate-300">
            {field.label}
            <input value={card[field.id]} maxLength={field.max} onChange={(event) => update(field.id, event.target.value)} className={inputClass} />
          </label>
        ))}
        <label className="text-sm text-slate-300">
          Blood group
          <select value={card.bloodGroup} onChange={(event) => update('bloodGroup', event.target.value)} className={inputClass}>
            {BLOOD_GROUPS.map((group) => (
              <option key={group} value={group}>
                {group || 'Choose'}
              </option>
            ))}
          </select>
        </label>
        {FIELDS.slice(1).map((field) => (
          <label key={field.id} className="text-sm text-slate-300">
            {field.label}
            <input
              type={field.type ?? 'text'}
              value={card[field.id]}
              maxLength={field.max}
              placeholder={field.placeholder}
              onChange={(event) => update(field.id, event.target.value)}
              className={inputClass}
            />
          </label>
        ))}
        <div className="flex flex-wrap gap-2 sm:col-span-2">
          <button type="submit" className="rounded-lg bg-teal-400 px-4 py-2 text-sm font-semibold text-navy-950 hover:bg-teal-300">
            Save card
          </button>
          {hasSaved && (
            <>
              <button
                type="button"
                onClick={() => setShowing(true)}
                className="rounded-lg border border-white/15 px-4 py-2 text-sm font-semibold text-white hover:border-white/30"
              >
                Show to responder
              </button>
              <button type="button" onClick={remove} className="rounded-lg border border-danger/40 px-4 py-2 text-sm font-semibold text-red-200 hover:bg-danger/15">
                Delete card
              </button>
            </>
          )}
        </div>
        <p role="status" className="min-h-5 text-xs text-slate-400 sm:col-span-2">
          {status}
        </p>
      </form>

      {showing && (
        <div role="dialog" aria-modal="true" aria-labelledby="medical-view-title" className="fixed inset-0 z-[100] overflow-y-auto bg-white p-6 text-slate-900">
          <div className="mx-auto max-w-lg">
            <h2 id="medical-view-title" className="font-display text-3xl font-bold text-red-700">
              Medical information
            </h2>
            <dl className="mt-6 space-y-4 text-xl">
              {[['Name', card.name], ['Blood group', card.bloodGroup], ...FIELDS.slice(1).map((field) => [field.label, card[field.id]])].map(
                ([label, value]) => (
                  <div key={label}>
                    <dt className="text-base text-slate-500">{label}</dt>
                    <dd className="font-semibold">{value || 'Not given'}</dd>
                  </div>
                ),
              )}
            </dl>
            <button
              type="button"
              onClick={() => setShowing(false)}
              autoFocus
              className="mt-8 w-full rounded-xl border-2 border-slate-300 px-6 py-3 text-lg font-semibold text-slate-700"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </section>
  )
}
