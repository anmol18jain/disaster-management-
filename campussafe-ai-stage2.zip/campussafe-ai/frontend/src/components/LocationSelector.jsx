import { ChevronDown, MapPin } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useCampus } from '../context/CampusContext.jsx'
import { getStartPlaces } from '../utils/campus.js'

function NoPlaces() {
  return (
    <p className="rounded-xl border border-dashed border-white/15 p-4 text-sm text-slate-300">
      No buildings are mapped on this campus yet.{' '}
      <Link to="/mapper" className="font-semibold text-teal-300 hover:text-teal-200">
        Map your campus
      </Link>{' '}
      or switch to the demo campus.
    </p>
  )
}

/**
 * Lets the user say where they are.
 * - variant "select": compact dropdown (dashboard)
 * - variant "cards":  large tap targets (emergency dialog)
 * Location is chosen manually because GPS cannot reliably place someone inside a building.
 */
export default function LocationSelector({ value, onChange, variant = 'select', name = 'location' }) {
  const { campus } = useCampus()
  const places = getStartPlaces(campus)

  if (variant === 'cards') {
    return (
      <fieldset>
        <legend className="mb-3 text-sm text-slate-300">Where are you right now?</legend>
        {places.length === 0 ? (
          <NoPlaces />
        ) : (
          <div className="grid gap-2 sm:grid-cols-2">
            {places.map((place) => {
              const checked = value === place.id
              return (
                <label
                  key={place.id}
                  className={`flex items-start gap-3 rounded-xl border p-3.5 transition-colors ${
                    checked ? 'border-teal-300 bg-teal-400/10' : 'border-white/10 hover:border-white/25 hover:bg-white/5'
                  }`}
                >
                  <input
                    type="radio"
                    name={name}
                    value={place.id}
                    checked={checked}
                    onChange={() => onChange(place.id)}
                    className="mt-1 size-4 accent-teal-400"
                  />
                  <span>
                    <span className="block font-semibold text-white">{place.name}</span>
                    {place.description && <span className="block text-sm text-slate-400">{place.description}</span>}
                  </span>
                </label>
              )
            })}
          </div>
        )}
      </fieldset>
    )
  }

  return (
    <div>
      <label htmlFor="location-select" className="mb-2 block text-sm font-medium text-slate-300">
        Current location
      </label>
      {places.length === 0 ? (
        <NoPlaces />
      ) : (
        <>
          <div className="relative">
            <MapPin className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-teal-300" aria-hidden="true" />
            <select
              id="location-select"
              value={value ?? ''}
              onChange={(event) => onChange(event.target.value || null)}
              className="w-full appearance-none rounded-xl border border-white/15 bg-navy-850 py-3 pl-10 pr-10 text-sm text-white transition-colors hover:border-white/30"
            >
              <option value="">Choose a building or location</option>
              {places.map((place) => (
                <option key={place.id} value={place.id}>
                  {place.name}
                </option>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
          </div>
          <p className="mt-2 text-xs text-slate-500">Choose it yourself: GPS is unreliable inside buildings.</p>
        </>
      )}
    </div>
  )
}
