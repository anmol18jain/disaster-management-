import { Building2, DoorOpen, Shield, Users } from 'lucide-react'

const KIND_ICONS = { assembly: Users, gate: DoorOpen, refuge: Shield, building: Building2 }

/** Evacuation destinations. Shows a clear warning when there are none. */
export default function DestinationList({ destinations }) {
  if (destinations.length === 0) {
    return (
      <p className="mt-2 text-sm text-caution">
        No destination is marked as suitable for this emergency on this campus. Follow instructions from emergency
        personnel and wardens.
      </p>
    )
  }

  return (
    <ul className="mt-2 divide-y divide-white/5">
      {destinations.map((destination) => {
        const Icon = KIND_ICONS[destination.kind] ?? Users
        return (
          <li key={destination.id} className="flex items-start gap-3 py-2.5">
            <span className="mt-0.5 grid size-7 shrink-0 place-items-center rounded-md bg-safe/15 text-safe">
              <Icon className="size-4" aria-hidden="true" />
            </span>
            <div>
              <p className="text-sm font-medium text-white">
                {destination.name}
                {destination.verified === false && <span className="ml-2 text-xs font-normal text-caution">not verified</span>}
              </p>
              {destination.description && <p className="text-xs leading-relaxed text-slate-400">{destination.description}</p>}
            </div>
          </li>
        )
      })}
    </ul>
  )
}
