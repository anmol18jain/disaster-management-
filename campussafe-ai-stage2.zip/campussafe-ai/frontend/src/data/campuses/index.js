import { DEMO_CAMPUS } from './demoCampus.js'
import { UPES_BIDHOLI } from './upesBidholi.js'

/** Every campus the app knows about. The first one is the default. */
export const CAMPUSES = [UPES_BIDHOLI, DEMO_CAMPUS]
export const DEFAULT_CAMPUS_ID = UPES_BIDHOLI.id
