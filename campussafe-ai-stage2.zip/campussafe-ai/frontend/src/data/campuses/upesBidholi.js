/**
 * UPES Bidholi campus (Energy Acres), Dehradun.
 *
 * This file deliberately contains NO buildings or paths. Their positions must
 * come from your own survey (Campus mapper page) or from official UPES plans,
 * never from guesses. Survey data is saved in the browser and can be exported
 * as a JSON file and shared with your team.
 *
 * defaultView is only an APPROXIMATE starting view of the Bidholi area. In the
 * Campus mapper, pan to the campus and tap "Save this view" to correct it.
 */
export const UPES_BIDHOLI = {
  id: 'upes-bidholi',
  name: 'UPES Bidholi (Energy Acres)',
  shortName: 'UPES Bidholi',
  isFictional: false,
  editable: true,
  crs: 'earth',
  defaultView: { center: [30.4163, 77.9674], zoom: 17 },
  places: [],
  paths: [],
}
