/**
 * FICTIONAL demonstration campus, used for demos and testing.
 * It is drawn on a blank canvas (no real map), with coordinates in metres:
 * lat = metres north of the south-west corner, lng = metres east of it.
 */
const PLACES = [
  { id: 'engineering', kind: 'building', name: 'Engineering Building', floors: 4, description: 'Lecture halls, workshops and computer labs.', lat: 260, lng: 370 },
  { id: 'science', kind: 'building', name: 'Science Building', floors: 3, description: 'Teaching labs, including a chemistry lab.', lat: 390, lng: 360 },
  {
    id: 'library',
    kind: 'building',
    name: 'Library',
    floors: 3,
    description: 'Reading rooms. The ground floor is the shelter when people are told to shelter in place.',
    lat: 260,
    lng: 135,
    suitableFor: ['chemical'],
  },
  { id: 'administration', kind: 'building', name: 'Administration Building', floors: 2, description: 'Offices and the security control room.', lat: 160, lng: 250 },
  { id: 'hostel', kind: 'building', name: 'Student Hostel', floors: 5, description: 'Residential block.', lat: 400, lng: 120 },
  {
    id: 'main-gate',
    kind: 'gate',
    name: 'Main Gate',
    description: 'Leaves campus. Use only when an off-campus evacuation is ordered.',
    lat: 50,
    lng: 250,
    suitableFor: ['general', 'chemical'],
  },
  {
    id: 'assembly-a',
    kind: 'assembly',
    name: 'Assembly Point A',
    description: 'North sports field. Flat, open and low-lying.',
    lat: 460,
    lng: 240,
    suitableFor: ['fire', 'earthquake', 'general', 'landslide'],
  },
  {
    id: 'assembly-b',
    kind: 'assembly',
    name: 'Assembly Point B',
    description: 'East upper lawn. Open ground, raised above the rest of campus.',
    lat: 110,
    lng: 450,
    suitableFor: ['fire', 'earthquake', 'flood', 'general'],
  },
  { id: 'junction-central', kind: 'junction', name: 'Central crossing', lat: 260, lng: 250 },
  { id: 'junction-north', kind: 'junction', name: 'North crossing', lat: 350, lng: 250 },
].map((place) => ({ floors: null, description: '', suitableFor: [], verified: true, ...place }))

const PATHS = [
  ['main-gate', 'administration', { stepFree: true }],
  ['administration', 'junction-central', { stepFree: true }],
  ['junction-central', 'library', { stepFree: true }],
  ['junction-central', 'engineering', { stepFree: true }],
  ['junction-central', 'junction-north', { stepFree: true }],
  ['junction-north', 'hostel', { stepFree: true }],
  ['junction-north', 'science', { stepFree: true }],
  ['junction-north', 'assembly-a', { stepFree: true, tags: ['low-lying'] }],
  ['engineering', 'assembly-b', { stepFree: true, tags: ['slope'] }],
  ['administration', 'assembly-b', { stepFree: false, tags: ['slope'] }],
].map(([from, to, extra], index) => ({ id: `path-${index + 1}`, from, to, stepFree: false, tags: [], verified: true, ...extra }))

export const DEMO_CAMPUS = {
  id: 'demo',
  name: 'Northbridge Demo Campus',
  shortName: 'Demo campus',
  isFictional: true,
  editable: false,
  crs: 'simple',
  bounds: [
    [0, 0],
    [500, 500],
  ],
  defaultView: null,
  places: PLACES,
  paths: PATHS,
}
