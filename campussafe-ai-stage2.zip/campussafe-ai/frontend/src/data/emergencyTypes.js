/**
 * Emergency types and the rules attached to each one.
 *
 * - routeRules:      plain-language summary of how routes are restricted.
 * - avoidHazardTags: walkways tagged with any of these will be excluded by
 *                    the routing engine in Stage 3.
 * - instructions:    general public-safety guidance. Replace it with text
 *                    approved by your university's safety office. It does
 *                    NOT replace official emergency procedures.
 */
export const EMERGENCY_TYPES = [
  {
    id: 'fire',
    label: 'Fire',
    summary: 'Leave the building and go to an outdoor assembly point away from smoke.',
    avoidHazardTags: ['fire', 'smoke', 'elevator'],
    routeRules: [
      'Paths through fire or smoke zones are excluded.',
      'Elevators are never part of a fire route.',
    ],
    instructions: [
      'Raise the alarm using the nearest fire alarm point if it is safe to do so.',
      'Leave immediately by the stairs. Do not use elevators unless emergency personnel tell you to.',
      'Close doors behind you to slow the spread of fire and smoke.',
      'If there is smoke, stay low, where the air is clearer.',
      'Do not go back inside until authorized personnel say it is safe.',
    ],
    requiresOfficialDecision: false,
  },
  {
    id: 'earthquake',
    label: 'Earthquake',
    summary: 'Drop, cover and hold on. Move to open ground only after the shaking stops.',
    avoidHazardTags: ['structural-damage', 'falling-debris', 'elevator'],
    routeRules: [
      'Paths beside damaged structures are excluded.',
      'Destinations must be open ground away from buildings.',
    ],
    instructions: [
      'While the ground is shaking: drop, take cover under sturdy furniture and hold on.',
      'Keep away from windows, shelves and anything that could fall.',
      'Leave only after the shaking stops, or when you are told to. Expect aftershocks.',
      'Use the stairs, not elevators, and watch for debris on the way out.',
      'Outside, move to open ground away from buildings, trees and power lines.',
    ],
    requiresOfficialDecision: false,
  },
  {
    id: 'flood',
    label: 'Flood',
    summary: 'Move to higher ground. Low-lying paths and assembly points are excluded.',
    avoidHazardTags: ['flooded', 'low-lying'],
    routeRules: [
      'Flooded and low-lying paths are excluded.',
      'Only raised destinations are allowed.',
    ],
    instructions: [
      'Move to higher ground straight away.',
      'Never walk or drive through moving or standing floodwater.',
      'Avoid basements, underpasses and low-lying paths.',
      'Stay away from electrical equipment and fallen power lines.',
      'Keep listening for announcements, because rising water can cut off routes quickly.',
    ],
    requiresOfficialDecision: false,
  },
  {
    id: 'chemical',
    label: 'Chemical hazard',
    summary: 'Emergency personnel decide whether to shelter indoors or leave. Wait for that instruction.',
    avoidHazardTags: ['chemical'],
    routeRules: [
      'Paths near the release are excluded.',
      'Wind direction data is not connected, so upwind routes cannot be checked.',
    ],
    instructions: [
      'Follow the official instruction to either shelter in place or evacuate.',
      'If sheltering: go indoors, close windows and doors, and switch off ventilation if told to.',
      'If evacuating: move away from the source, upwind and uphill where possible.',
      'Do not touch spilled material or try to clean it up.',
      'Tell responders if you have eye, skin or breathing irritation.',
    ],
    requiresOfficialDecision: true,
    officialDecisionNote:
      'Whether to shelter indoors or leave campus depends on the substance, where it was released and the wind. Only emergency personnel can make that call, and this prototype has no wind data.',
  },
  {
    id: 'landslide',
    label: 'Landslide',
    summary: 'Move sideways out of the path of the slide, onto stable higher ground away from slopes.',
    avoidHazardTags: ['slope', 'landslide'],
    routeRules: [
      'Paths along slopes and road cuttings are excluded.',
      'Destinations must be flat ground away from slopes.',
    ],
    instructions: [
      'During heavy or long rain, keep away from steep slopes, road cuttings and retaining walls.',
      'Watch for warning signs: rumbling, cracking trees, tilting poles, new cracks in the ground or walls.',
      'If the ground starts moving, get out of its path by moving sideways, not downhill.',
      'Stay away from the slide area afterwards, because more slides can follow.',
      'Do not cross debris or flooded road sections. Report blocked roads and fallen power lines.',
    ],
    requiresOfficialDecision: false,
  },
  {
    id: 'general',
    label: 'General evacuation',
    summary: 'Leave by the nearest safe exit and report to your assembly point.',
    avoidHazardTags: [],
    routeRules: ['Blocked paths are excluded.'],
    instructions: [
      'Stay calm and follow instructions from wardens and security staff.',
      'Leave by the nearest safe exit and take only essentials.',
      'Help anyone who needs assistance, if it is safe to do so.',
      'Report to your warden at the assembly point so you can be counted.',
      'Do not leave the assembly point until you are told to.',
    ],
    requiresOfficialDecision: false,
  },
]
