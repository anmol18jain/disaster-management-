/**
 * Survival guide content.
 * General public-safety and first-aid guidance (fire services, Red Cross,
 * resuscitation councils). It does not replace training or instructions from
 * emergency personnel. Ask your campus safety office to review it.
 *
 * Fields: steps (what to do), avoid (what not to do), tool (an SOS tool that helps).
 */
export const GUIDE_SECTIONS = [
  {
    id: 'fire-escape',
    title: 'Fire: getting out',
    icon: 'fire',
    steps: [
      'Shout "Fire!" and raise the alarm at the nearest alarm point.',
      'Before opening a door, touch it and the handle with the back of your hand. If it is hot, keep it shut and use another way out.',
      'Leave by the stairs. Do not use lifts.',
      'If there is smoke, crawl low where the air is cleaner and cover your nose and mouth with cloth.',
      'Close doors behind you to slow the fire.',
      'Go to your assembly point and tell a warden if anyone is missing. Never go back inside.',
    ],
    avoid: ['Stopping to collect belongings', 'Using lifts', 'Opening a hot door', 'Hiding in toilets, cupboards or under beds'],
  },
  {
    id: 'fire-trapped',
    title: 'Fire: if you are trapped',
    icon: 'fire',
    urgent: true,
    steps: [
      'Get into a room with a window, close the door and keep it closed.',
      'Block the gap under the door and any vents with clothes, towels or bedding. Wet them if you can.',
      'Call 112. Say the building, floor and room number, and that you are trapped.',
      'Signal from the window: wave something bright, or use the screen light or SOS sound in SOS tools.',
      'Stay low if smoke gets in. Open the window for air only if there is no smoke outside, and close it if smoke comes in.',
      'Stay near the window where rescuers can see you.',
      'Last resort, ground or first floor only: drop bedding below, climb out feet first, hang from the sill by your arms, then let go. From higher floors, wait for rescue.',
    ],
    avoid: ['Opening the door to check', 'Jumping from upper floors'],
    tool: 'light',
  },
  {
    id: 'clothes-fire',
    title: 'If clothes catch fire',
    icon: 'fire',
    steps: [
      'Stop where you are. Running makes flames worse.',
      'Drop to the ground and cover your face with your hands.',
      'Roll over and over until the flames are out.',
      'Helping someone else: get them to stop, drop and roll, or smother the flames with a heavy coat or blanket.',
      'Then treat the burn (see Burns).',
    ],
  },
  {
    id: 'burns',
    title: 'Burns: first aid',
    icon: 'medical',
    steps: [
      'Cool the burn under cool or lukewarm running water for 20 minutes.',
      'Remove rings, watches and clothing near the burn, unless they are stuck to the skin.',
      'Cover loosely with cling film or a clean plastic bag.',
      'Call 108 for large or deep burns; burns to the face, hands, feet or groin; chemical or electrical burns; or if the person breathed in smoke.',
    ],
    avoid: ['Ice or iced water', 'Butter, toothpaste or creams', 'Popping blisters'],
  },
  {
    id: 'smoke',
    title: 'Smoke inhalation',
    icon: 'medical',
    steps: [
      'Get the person into fresh air.',
      'Warning signs: coughing, breathlessness, a hoarse voice, confusion, headache, soot around the nose or mouth.',
      'Call 108 even if they seem fine. Symptoms can get worse hours later.',
    ],
  },
  {
    id: 'earthquake',
    title: 'Earthquake',
    icon: 'earthquake',
    steps: [
      'While shaking: drop, take cover under a sturdy table and hold on.',
      'Indoors, stay inside until the shaking stops. Keep away from windows and shelves.',
      'Outdoors, move to open ground away from buildings, trees and power lines.',
      'Afterwards, expect aftershocks. Leave a damaged building by the stairs.',
    ],
    avoid: ['Running outside while the ground is shaking', 'Using lifts'],
  },
  {
    id: 'earthquake-trapped',
    title: 'Trapped under debris',
    icon: 'earthquake',
    urgent: true,
    steps: [
      'Stay still to avoid raising dust, and cover your mouth with cloth.',
      'Tap on a pipe or wall, blow a whistle or play the SOS sound so rescuers can hear you.',
      'Shout only as a last resort, because it makes you breathe in dust and tires you out.',
      'If the network is busy, a text message is more likely to get through than a call.',
    ],
    avoid: ['Lighting matches or lighters (there may be gas)'],
    tool: 'sound',
  },
  {
    id: 'landslide',
    title: 'Landslide',
    icon: 'landslide',
    steps: [
      'In heavy or long rain, keep away from steep slopes, road cuttings and retaining walls.',
      'Warning signs: rumbling, cracking trees, tilting poles or fences, new cracks in the ground or walls, sudden muddy water in streams.',
      'If the ground moves, get out of its path by moving sideways onto stable ground, not downhill.',
      'Stay away afterwards, because more slides can follow.',
    ],
    avoid: ['Crossing debris or flooded road sections'],
  },
  {
    id: 'flood',
    title: 'Flood and flash flood',
    icon: 'flood',
    steps: [
      'Move to higher ground straight away.',
      'Keep away from streams and drainage channels during heavy rain.',
      'Stay away from electrical equipment and fallen power lines.',
    ],
    avoid: ['Walking or driving through moving water', 'Basements and underpasses'],
  },
  {
    id: 'gas-leak',
    title: 'Gas leak (LPG)',
    icon: 'chemical',
    steps: [
      'Do not switch lights or appliances on or off, and do not use flames or lighters.',
      'If it is safe, turn off the cylinder regulator and open doors and windows.',
      'Leave the area and warn others.',
      'Call 112 or the gas leak helpline 1906 from outside, away from the smell.',
    ],
  },
  {
    id: 'chemical-spill',
    title: 'Lab chemical spill',
    icon: 'chemical',
    steps: [
      'Leave the area, warn others and close the door behind you.',
      'If chemicals touch your skin or eyes, rinse with plenty of running water for at least 15 to 20 minutes. Use the lab eyewash or safety shower.',
      'Take off contaminated clothing.',
      'Tell lab staff and follow the lab’s safety instructions.',
    ],
    avoid: ['Cleaning up a spill yourself', 'Smelling or touching unknown substances'],
  },
  {
    id: 'electric-shock',
    title: 'Electric shock',
    icon: 'medical',
    steps: [
      'Do not touch the person while they are still in contact with the source.',
      'Switch off the power at the mains if you can.',
      'If you cannot, stand on something dry and push the source away with something dry and non-metal, such as a wooden broom.',
      'Call 108. Start CPR if they are not breathing normally.',
      'For power lines or high voltage, stay well back and call 112.',
    ],
  },
  {
    id: 'cpr',
    title: 'Hands-only CPR (adult)',
    icon: 'medical',
    urgent: true,
    steps: [
      'If someone is unresponsive and not breathing normally, call 108 and put the phone on speaker.',
      'Push hard and fast in the centre of the chest: about 5 to 6 cm deep, 100 to 120 times a minute.',
      'Keep going until help arrives or the person starts breathing normally.',
      'If a defibrillator (AED) is available, switch it on and follow its spoken instructions.',
    ],
  },
  {
    id: 'crowd',
    title: 'Crowds and crushes',
    icon: 'general',
    steps: [
      'Move with the crowd and work your way diagonally towards the edge.',
      'Keep your arms up in front of your chest to protect your breathing space.',
      'If you fall, get up immediately. If you cannot, curl up on your side and protect your head.',
    ],
    avoid: ['Pushing against the crowd', 'Stopping to pick things up'],
  },
]
