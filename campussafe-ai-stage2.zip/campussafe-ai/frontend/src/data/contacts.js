/**
 * Emergency contacts.
 *
 * Public numbers were checked in October 2026 against official Uttarakhand
 * sources (listed in `source`). Re-check them before any real use.
 *
 * Campus numbers are null on purpose: a safety app must never show guessed
 * numbers. Ask the UPES security office for the verified 24x7 numbers and
 * enter them here, for example:  phone: '+91 00000 00000',
 */
export const CONTACT_GROUPS = [
  { id: 'public', title: 'Public emergency numbers (India, Uttarakhand)' },
  { id: 'campus', title: 'Campus contacts' },
]

export const EMERGENCY_CONTACTS = [
  {
    id: 'emergency-112',
    group: 'public',
    name: 'Emergency (police, fire, ambulance)',
    description: 'India’s single emergency number. Use it when you are not sure who to call.',
    phone: '112',
    source: 'Uttarakhand Fire and Emergency Service website',
  },
  {
    id: 'ambulance',
    group: 'public',
    name: 'Ambulance',
    description: 'Free, 24x7 emergency medical service across Uttarakhand.',
    phone: '108',
    source: 'National Health Mission, Uttarakhand',
  },
  {
    id: 'fire',
    group: 'public',
    name: 'Fire service',
    description: 'Fire helpline.',
    phone: '101',
    source: 'Uttarakhand state helpline listings',
  },
  {
    id: 'gas-leak',
    group: 'public',
    name: 'LPG gas leak',
    description: 'Gas leak emergency helpline.',
    phone: '1906',
    source: 'Uttarakhand state helpline listings',
  },
  {
    id: 'campus-security',
    group: 'campus',
    name: 'UPES campus security',
    description: 'Security control room. Ask the security office for the 24x7 number.',
    phone: null,
  },
  {
    id: 'campus-health',
    group: 'campus',
    name: 'UPES health centre',
    description: 'On-campus medical help.',
    phone: null,
  },
  {
    id: 'hostel-warden',
    group: 'campus',
    name: 'Your hostel warden',
    description: 'For hostel evacuations and roll calls.',
    phone: null,
  },
]
