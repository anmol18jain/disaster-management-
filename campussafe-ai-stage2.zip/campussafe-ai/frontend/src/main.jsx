import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.jsx'
import { CampusProvider } from './context/CampusContext.jsx'
import { EmergencyProvider } from './context/EmergencyContext.jsx'
import 'leaflet/dist/leaflet.css'
import './App.css'

// Entry point: React takes over the <div id="root"> in index.html.
// BrowserRouter enables page URLs. CampusProvider holds the map data, and
// EmergencyProvider holds your selections; both are shared across pages.
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <CampusProvider>
        <EmergencyProvider>
          <App />
        </EmergencyProvider>
      </CampusProvider>
    </BrowserRouter>
  </StrictMode>,
)
