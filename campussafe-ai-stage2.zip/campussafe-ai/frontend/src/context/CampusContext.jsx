import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { CAMPUSES, DEFAULT_CAMPUS_ID } from '../data/campuses/index.js'
import { makeId, readJson, writeJson } from '../utils/storage.js'
import { validateSurvey } from '../utils/survey.js'

const PREFIX = 'campussafe:v1:'
const ACTIVE_KEY = `${PREFIX}active-campus`
const surveyKey = (campusId) => `${PREFIX}survey:${campusId}`

function loadSurvey(campus) {
  const result = validateSurvey(readJson(surveyKey(campus.id)))
  return result.ok ? result.data : { places: campus.places, paths: campus.paths, view: null }
}

const CampusContext = createContext(null)

/**
 * Which campus is shown, and the survey data for campuses you can edit.
 * Survey data is saved in this browser (localStorage) after every change.
 */
export function CampusProvider({ children }) {
  const [activeCampusId, setActiveCampusId] = useState(() => {
    const saved = readJson(ACTIVE_KEY)
    return CAMPUSES.some((campus) => campus.id === saved) ? saved : DEFAULT_CAMPUS_ID
  })
  const [surveys, setSurveys] = useState(() =>
    Object.fromEntries(CAMPUSES.filter((campus) => campus.editable).map((campus) => [campus.id, loadSurvey(campus)])),
  )
  const [storageFailed, setStorageFailed] = useState(false)

  useEffect(() => {
    writeJson(ACTIVE_KEY, activeCampusId)
  }, [activeCampusId])

  useEffect(() => {
    const allSaved = Object.entries(surveys).every(([campusId, survey]) => writeJson(surveyKey(campusId), survey))
    setStorageFailed(!allSaved)
  }, [surveys])

  const base = CAMPUSES.find((campus) => campus.id === activeCampusId) ?? CAMPUSES[0]

  // The campus everyone else reads: fixed details merged with any survey data.
  const campus = useMemo(() => {
    if (!base.editable) return { ...base, view: base.defaultView, hasSavedView: false }
    const survey = surveys[base.id]
    return {
      ...base,
      places: survey.places,
      paths: survey.paths,
      view: survey.view ?? base.defaultView,
      hasSavedView: Boolean(survey.view),
    }
  }, [base, surveys])

  // Every edit goes through here and only touches the active, editable campus.
  const updateSurvey = useCallback(
    (updater) => {
      setSurveys((previous) => (previous[activeCampusId] ? { ...previous, [activeCampusId]: updater(previous[activeCampusId]) } : previous))
    },
    [activeCampusId],
  )

  const addPlace = useCallback(
    (place) => {
      const id = makeId(place.kind ?? 'place')
      updateSurvey((survey) => ({ ...survey, places: [...survey.places, { suitableFor: [], verified: false, floors: null, description: '', ...place, id }] }))
      return id
    },
    [updateSurvey],
  )

  const updatePlace = useCallback(
    (id, changes) => {
      updateSurvey((survey) => ({ ...survey, places: survey.places.map((place) => (place.id === id ? { ...place, ...changes } : place)) }))
    },
    [updateSurvey],
  )

  // Removing a place also removes every walkway connected to it.
  const removePlace = useCallback(
    (id) => {
      updateSurvey((survey) => ({
        ...survey,
        places: survey.places.filter((place) => place.id !== id),
        paths: survey.paths.filter((path) => path.from !== id && path.to !== id),
      }))
    },
    [updateSurvey],
  )

  const addPath = useCallback(
    (from, to) => {
      updateSurvey((survey) => {
        const ids = new Set(survey.places.map((place) => place.id))
        const exists = survey.paths.some((path) => (path.from === from && path.to === to) || (path.from === to && path.to === from))
        if (from === to || !ids.has(from) || !ids.has(to) || exists) return survey
        return { ...survey, paths: [...survey.paths, { id: makeId('path'), from, to, stepFree: true, tags: [], verified: false }] }
      })
    },
    [updateSurvey],
  )

  const updatePath = useCallback(
    (id, changes) => {
      updateSurvey((survey) => ({ ...survey, paths: survey.paths.map((path) => (path.id === id ? { ...path, ...changes } : path)) }))
    },
    [updateSurvey],
  )

  const removePath = useCallback(
    (id) => updateSurvey((survey) => ({ ...survey, paths: survey.paths.filter((path) => path.id !== id) })),
    [updateSurvey],
  )

  const saveView = useCallback((view) => updateSurvey((survey) => ({ ...survey, view })), [updateSurvey])

  const replaceSurvey = useCallback((data) => updateSurvey(() => data), [updateSurvey])

  const clearSurvey = useCallback(() => updateSurvey((survey) => ({ ...survey, places: [], paths: [] })), [updateSurvey])

  const value = useMemo(
    () => ({
      campuses: CAMPUSES,
      activeCampusId,
      setActiveCampusId,
      campus,
      storageFailed,
      addPlace,
      updatePlace,
      removePlace,
      addPath,
      updatePath,
      removePath,
      saveView,
      replaceSurvey,
      clearSurvey,
    }),
    [activeCampusId, campus, storageFailed, addPlace, updatePlace, removePlace, addPath, updatePath, removePath, saveView, replaceSurvey, clearSurvey],
  )

  return <CampusContext.Provider value={value}>{children}</CampusContext.Provider>
}

export function useCampus() {
  const context = useContext(CampusContext)
  if (!context) throw new Error('useCampus() must be used inside <CampusProvider>.')
  return context
}
