import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { findEmergencyType, findPlace, START_KINDS } from '../utils/campus.js'
import { useCampus } from './CampusContext.jsx'

/**
 * Shared app state ("context").
 *
 * Any component can read or change the user's choices by calling useEmergency().
 * Keeping these choices in one place means the dashboard, the map (Stage 2),
 * the routing engine (Stage 3) and the admin tools (Stage 5) all stay in sync.
 */
const EmergencyContext = createContext(null)

export function EmergencyProvider({ children }) {
  const { campus } = useCampus()
  const [locationId, setLocationId] = useState(null)
  const [emergencyTypeId, setEmergencyTypeId] = useState(null)
  const [needsStepFree, setNeedsStepFree] = useState(false)
  const [emergencyMode, setEmergencyMode] = useState(false)
  const [wizardOpen, setWizardOpen] = useState(false)

  // Turns on the (simulated) emergency mode and opens the step-by-step dialog.
  const startEmergency = useCallback(() => {
    setEmergencyMode(true)
    setWizardOpen(true)
  }, [])

  // Ends the simulation. The user's selections are kept.
  const endEmergency = useCallback(() => {
    setEmergencyMode(false)
    setWizardOpen(false)
  }, [])

  const closeWizard = useCallback(() => setWizardOpen(false), [])

  // A location from one campus means nothing on another, so clear it when the campus changes.
  useEffect(() => {
    setLocationId(null)
  }, [campus.id])

  const place = findPlace(campus, locationId)
  const selectedLocation = place && START_KINDS.includes(place.kind) ? place : null

  const value = useMemo(
    () => ({
      locationId,
      setLocationId,
      emergencyTypeId,
      setEmergencyTypeId,
      needsStepFree,
      setNeedsStepFree,
      emergencyMode,
      startEmergency,
      endEmergency,
      wizardOpen,
      closeWizard,
      // Full objects, ready to display (null when nothing is selected).
      selectedLocation,
      selectedEmergency: findEmergencyType(emergencyTypeId),
    }),
    [locationId, emergencyTypeId, needsStepFree, emergencyMode, wizardOpen, startEmergency, endEmergency, closeWizard, selectedLocation],
  )

  return <EmergencyContext.Provider value={value}>{children}</EmergencyContext.Provider>
}

export function useEmergency() {
  const context = useContext(EmergencyContext)
  if (!context) {
    throw new Error('useEmergency() must be used inside <EmergencyProvider>.')
  }
  return context
}
