import { Link } from 'react-router-dom'
import Logo from '../components/Logo.jsx'

/** Shown for any URL that doesn't match a page. */
export default function NotFoundPage() {
  return (
    <div className="grid min-h-dvh place-items-center bg-navy-950 px-5 text-center">
      <div>
        <Logo />
        <h1 className="mt-8 font-display text-4xl font-bold text-white">Page not found</h1>
        <p className="mt-2 text-slate-400">This address doesn't match any page in CampusSafe AI.</p>
        <div className="mt-6 flex justify-center gap-3">
          <Link to="/" className="rounded-xl border border-white/15 px-5 py-2.5 text-sm font-semibold text-white hover:border-white/30">
            Home
          </Link>
          <Link to="/dashboard" className="rounded-xl bg-teal-400 px-5 py-2.5 text-sm font-semibold text-navy-950 hover:bg-teal-300">
            Open dashboard
          </Link>
        </div>
      </div>
    </div>
  )
}
