import { useCallback, useRef, useState } from 'react'
import { Crosshair, Download, LocateFixed, MousePointer2, Plus, Route, Save, Trash2, Upload } from 'lucide-react'
import CampusMap from '../components/map/CampusMap.jsx'
import PathEditor from '../components/mapper/PathEditor.jsx'
import PlaceForm from '../components/mapper/PlaceForm.jsx'
import { useCampus } from '../context/CampusContext.jsx'
import { useGeolocation } from '../hooks/useGeolocation.js'
import { describeCampusData, findPlace } from '../utils/campus.js'
import { distanceMeters, formatDistance } from '../utils/geo.js'
import { buildSurveyExport, validateSurvey } from '../utils/survey.js'

const MODES = [
  { id: 'select', label: 'Select', icon: MousePointer2, help: 'Tap a place or walkway to edit it. Drag a selected place to move it.' },
  { id: 'add', label: 'Add place', icon: Plus, help: 'Tap the map, or line the crosshair up and press "Add at crosshair".' },
  {
    id: 'path',
    label: 'Draw walkway',
    icon: Route,
    help: 'Tap a place to start, then tap the next place. Tapping empty map adds a junction, so you can follow bends.',
  },
]

/**
 * Campus mapper: build the map of a real campus by surveying it.
 * Places and walkways become the graph the routing engine uses in Stage 3.
 */
export default function MapperPage() {
  const { campus, setActiveCampusId, addPlace, updatePlace, removePlace, addPath, updatePath, removePath, saveView, replaceSurvey, clearSurvey, storageFailed } =
    useCampus()
  const geo = useGeolocation()
  const [mode, setMode] = useState('select')
  const [selectedPlaceId, setSelectedPlaceId] = useState(null)
  const [selectedPathId, setSelectedPathId] = useState(null)
  const [pathFromId, setPathFromId] = useState(null)
  const [draft, setDraft] = useState(null) // { lat, lng } of a place being added
  const [message, setMessage] = useState('')
  const [map, setMap] = useState(null)
  const fileInputRef = useRef(null)
  const panelRef = useRef(null)

  const handleMapReady = useCallback((instance) => setMap(instance), [])
  const stats = describeCampusData(campus)
  const selectedPlace = findPlace(campus, selectedPlaceId)
  const selectedPath = campus.paths.find((path) => path.id === selectedPathId) ?? null
  const totalWalkway = campus.paths.reduce((sum, path) => {
    const from = findPlace(campus, path.from)
    const to = findPlace(campus, path.to)
    return from && to ? sum + distanceMeters(campus, from, to) : sum
  }, 0)

  if (!campus.editable) {
    return (
      <div className="mx-auto max-w-2xl">
        <h1 className="font-display text-3xl font-bold text-white sm:text-4xl">Campus mapper</h1>
        <p className="mt-3 text-slate-300">The demo campus is fictional and read-only. Switch to UPES Bidholi to map your campus.</p>
        <button
          type="button"
          onClick={() => setActiveCampusId('upes-bidholi')}
          className="mt-6 rounded-xl bg-teal-400 px-5 py-2.5 font-semibold text-navy-950 hover:bg-teal-300"
        >
          Switch to UPES Bidholi
        </button>
      </div>
    )
  }

  function changeMode(nextMode) {
    setMode(nextMode)
    setDraft(null)
    setPathFromId(null)
    setSelectedPlaceId(null)
    setSelectedPathId(null)
    setMessage('')
  }

  function openDraft(position) {
    setDraft(position)
    setSelectedPlaceId(null)
    setSelectedPathId(null)
    requestAnimationFrame(() => panelRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }))
  }

  function handleMapClick(position) {
    if (mode === 'add') {
      openDraft(position)
    } else if (mode === 'path') {
      const junctionCount = campus.places.filter((place) => place.kind === 'junction').length
      const id = addPlace({ kind: 'junction', name: `Junction ${junctionCount + 1}`, lat: position.lat, lng: position.lng })
      if (pathFromId) addPath(pathFromId, id)
      setPathFromId(id)
      setMessage(pathFromId ? 'Walkway added. Tap the next point, or press "Finish walkway".' : 'Junction added. Tap the next point.')
    } else {
      setSelectedPlaceId(null)
      setSelectedPathId(null)
    }
  }

  function handlePlaceClick(place) {
    if (mode === 'path') {
      if (!pathFromId) {
        setPathFromId(place.id)
        setMessage(`Starting at ${place.name}. Tap the next point.`)
      } else if (pathFromId === place.id) {
        setPathFromId(null)
        setMessage('Walkway drawing stopped.')
      } else {
        addPath(pathFromId, place.id)
        setPathFromId(place.id)
        setMessage(`Walkway added to ${place.name}. Tap the next point, or press "Finish walkway".`)
      }
      return
    }
    setDraft(null)
    setSelectedPathId(null)
    setSelectedPlaceId(place.id)
  }

  function handlePathClick(path) {
    if (mode !== 'select') return
    setSelectedPlaceId(null)
    setSelectedPathId(path.id)
  }

  function handlePlaceMove(id, position) {
    updatePlace(id, { ...position, verified: false })
    setMessage('Place moved. It is marked as not verified until you check it again.')
  }

  function handleSaveView() {
    if (!map) return
    const center = map.getCenter()
    saveView({ center: [center.lat, center.lng], zoom: map.getZoom() })
    setMessage('Saved. The map will open at this view.')
  }

  function handleExport() {
    const data = buildSurveyExport(campus)
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `campussafe-${campus.id}-${new Date().toISOString().slice(0, 10)}.json`
    link.click()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
    setMessage('Survey exported. Share the file with your team, or keep it as a backup.')
  }

  async function handleImport(event) {
    const file = event.target.files?.[0]
    event.target.value = '' // lets you pick the same file again later
    if (!file) return
    try {
      const result = validateSurvey(JSON.parse(await file.text()))
      if (!result.ok) {
        setMessage(result.skipped[0])
        return
      }
      const summary = `${result.data.places.length} places and ${result.data.paths.length} walkways`
      if (!window.confirm(`Replace the current survey with ${summary} from this file?`)) return
      replaceSurvey(result.data)
      changeMode('select')
      setMessage(`Imported ${summary}.${result.skipped.length ? ` Skipped ${result.skipped.length} invalid entries.` : ''}`)
    } catch {
      setMessage('That file could not be read. Choose a .json file exported from CampusSafe AI.')
    }
  }

  function handleClear() {
    if (!window.confirm('Delete every place and walkway on this campus? Export a backup first if you might need it.')) return
    clearSurvey()
    changeMode('select')
    setMessage('Survey cleared.')
  }

  const centerOfMap = () => {
    const center = map?.getCenter()
    return center ? { lat: center.lat, lng: center.lng } : null
  }

  return (
    <div className="mx-auto max-w-7xl">
      <h1 className="font-display text-3xl font-bold text-white sm:text-4xl">Campus mapper</h1>
      <p className="mt-1 max-w-3xl text-slate-400">
        Map {campus.name} by walking it. Mark buildings, the walkways between them and official assembly points. Use
        satellite view (top right of the map) to line places up.
      </p>

      {!campus.hasSavedView && (
        <p role="note" className="mt-4 rounded-xl border border-caution/40 bg-caution/10 p-3 text-sm text-amber-50">
          The starting view is approximate. Pan and zoom to the campus, then press <strong>Save this view</strong>.
        </p>
      )}
      {storageFailed && (
        <p role="alert" className="mt-4 rounded-xl border border-danger/40 bg-danger/10 p-3 text-sm text-red-100">
          Changes can’t be saved in this browser (storage is full or blocked). Export your survey to keep it.
        </p>
      )}

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
        <div>
          <div role="group" aria-label="Mapping tool" className="mb-3 flex flex-wrap gap-2">
            {MODES.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                type="button"
                aria-pressed={mode === id}
                onClick={() => changeMode(id)}
                className={`inline-flex items-center gap-2 rounded-xl border px-3.5 py-2 text-sm font-semibold transition-colors ${
                  mode === id ? 'border-teal-300 bg-teal-400/15 text-teal-100' : 'border-white/15 text-slate-300 hover:border-white/30 hover:text-white'
                }`}
              >
                <Icon className="size-4" aria-hidden="true" />
                {label}
              </button>
            ))}
          </div>

          <CampusMap
            campus={campus}
            className="h-[60dvh] min-h-[360px]"
            showJunctions
            crosshair={mode === 'add'}
            selectedPlaceId={selectedPlaceId}
            selectedPathId={selectedPathId}
            pendingPlaceId={pathFromId}
            draggablePlaceId={mode === 'select' ? selectedPlaceId : null}
            userPosition={geo.position}
            onMapClick={handleMapClick}
            onPlaceClick={handlePlaceClick}
            onPathClick={handlePathClick}
            onPlaceMove={handlePlaceMove}
            onMapReady={handleMapReady}
          />

          <p className="mt-3 text-sm text-slate-400">{MODES.find((item) => item.id === mode).help}</p>
          <p role="status" aria-live="polite" className="mt-1 min-h-5 text-sm font-medium text-teal-200">
            {message}
          </p>

          <div className="mt-2 flex flex-wrap gap-2">
            {mode === 'add' && (
              <>
                <button
                  type="button"
                  onClick={() => {
                    const center = centerOfMap()
                    if (center) openDraft(center)
                  }}
                  className="inline-flex items-center gap-2 rounded-lg bg-teal-400 px-3 py-2 text-sm font-semibold text-navy-950 hover:bg-teal-300"
                >
                  <Crosshair className="size-4" aria-hidden="true" /> Add at crosshair
                </button>
                <button
                  type="button"
                  onClick={geo.locate}
                  className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-2 text-sm font-semibold text-white hover:border-white/30"
                >
                  <LocateFixed className="size-4" aria-hidden="true" /> {geo.status === 'locating' ? 'Finding you…' : 'Get my GPS position'}
                </button>
                {geo.position && (
                  <button
                    type="button"
                    onClick={() => openDraft({ lat: geo.position.lat, lng: geo.position.lng })}
                    className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-2 text-sm font-semibold text-white hover:border-white/30"
                  >
                    Add at my position (±{geo.position.accuracy} m)
                  </button>
                )}
              </>
            )}
            {mode === 'path' && pathFromId && (
              <button
                type="button"
                onClick={() => {
                  setPathFromId(null)
                  setMessage('Walkway finished.')
                }}
                className="rounded-lg bg-teal-400 px-3 py-2 text-sm font-semibold text-navy-950 hover:bg-teal-300"
              >
                Finish walkway
              </button>
            )}
            <button
              type="button"
              onClick={handleSaveView}
              className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-2 text-sm font-semibold text-white hover:border-white/30"
            >
              <Save className="size-4" aria-hidden="true" /> Save this view
            </button>
          </div>
          {geo.status === 'error' && <p className="mt-2 text-sm text-caution">{geo.error}</p>}
        </div>

        <aside ref={panelRef} className="space-y-6">
          {(draft || selectedPlace || selectedPath) && (
            <section className="rounded-2xl border border-teal-300/30 bg-navy-900 p-5">
              {draft && (
                <PlaceForm
                  key={`draft-${draft.lat}-${draft.lng}`}
                  heading="New place"
                  submitLabel="Add place"
                  initial={{ kind: 'building' }}
                  onCancel={() => setDraft(null)}
                  onSave={(values) => {
                    addPlace({ ...values, lat: draft.lat, lng: draft.lng })
                    setDraft(null)
                    setMessage(`${values.name} added.`)
                  }}
                />
              )}
              {!draft && selectedPlace && (
                <PlaceForm
                  key={selectedPlace.id}
                  heading="Edit place"
                  submitLabel="Save changes"
                  initial={selectedPlace}
                  onCancel={() => setSelectedPlaceId(null)}
                  onSave={(values) => {
                    updatePlace(selectedPlace.id, values)
                    setSelectedPlaceId(null)
                    setMessage(`${values.name} saved.`)
                  }}
                  onDelete={() => {
                    if (!window.confirm(`Delete ${selectedPlace.name} and its walkways?`)) return
                    removePlace(selectedPlace.id)
                    setSelectedPlaceId(null)
                    setMessage(`${selectedPlace.name} deleted.`)
                  }}
                />
              )}
              {!draft && selectedPath && (
                <PathEditor
                  campus={campus}
                  path={selectedPath}
                  onChange={(changes) => updatePath(selectedPath.id, changes)}
                  onClose={() => setSelectedPathId(null)}
                  onDelete={() => {
                    removePath(selectedPath.id)
                    setSelectedPathId(null)
                    setMessage('Walkway deleted.')
                  }}
                />
              )}
            </section>
          )}

          <section aria-labelledby="survey-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
            <h2 id="survey-heading" className="font-display text-lg font-semibold text-white">
              Survey
            </h2>
            <dl className="mt-3 grid grid-cols-2 gap-3 text-sm">
              <div>
                <dt className="text-slate-400">Places</dt>
                <dd className="font-display text-2xl font-semibold text-white">{stats.mapped}</dd>
              </div>
              <div>
                <dt className="text-slate-400">Walkways</dt>
                <dd className="font-display text-2xl font-semibold text-white">{stats.paths}</dd>
              </div>
              <div>
                <dt className="text-slate-400">Walkway length</dt>
                <dd className="font-medium text-white">{formatDistance(totalWalkway)}</dd>
              </div>
              <div>
                <dt className="text-slate-400">Not verified</dt>
                <dd className={`font-medium ${stats.unverified ? 'text-caution' : 'text-safe'}`}>{stats.unverified}</dd>
              </div>
            </dl>
            <p className="mt-3 text-xs text-slate-500">Saved automatically in this browser only. Export it to back it up or share it.</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleExport}
                className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-2 text-sm font-semibold text-white hover:border-white/30"
              >
                <Download className="size-4" aria-hidden="true" /> Export
              </button>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-2 text-sm font-semibold text-white hover:border-white/30"
              >
                <Upload className="size-4" aria-hidden="true" /> Import
              </button>
              <input ref={fileInputRef} type="file" accept="application/json,.json" onChange={handleImport} className="sr-only" tabIndex={-1} aria-label="Import survey file" />
              <button
                type="button"
                onClick={handleClear}
                className="inline-flex items-center gap-2 rounded-lg border border-danger/40 px-3 py-2 text-sm font-semibold text-red-200 hover:bg-danger/15"
              >
                <Trash2 className="size-4" aria-hidden="true" /> Clear
              </button>
            </div>
          </section>

          <section aria-labelledby="tips-heading" className="rounded-2xl border border-white/10 bg-navy-900 p-5">
            <h2 id="tips-heading" className="font-display text-lg font-semibold text-white">
              Surveying tips
            </h2>
            <ul className="mt-3 space-y-2 text-sm leading-relaxed text-slate-400">
              <li>Ask the UPES safety or estate office for the official evacuation plan and assembly points first.</li>
              <li>Mark each building’s exits as junctions, then connect them with walkways.</li>
              <li>Record stairs (untick “Step-free”), slopes and low-lying stretches. They change which routes are safe.</li>
              <li>Tick “Verified on site” only after checking in person. GPS is often 5 to 20 m off near buildings.</li>
            </ul>
          </section>
        </aside>
      </div>
    </div>
  )
}
