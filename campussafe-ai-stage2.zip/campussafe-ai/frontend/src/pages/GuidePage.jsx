import { Link } from 'react-router-dom'
import { HeartPulse, Users } from 'lucide-react'
import EmergencyIcon from '../components/EmergencyIcon.jsx'
import { GUIDE_SECTIONS } from '../data/survivalGuide.js'

const TOOL_LINKS = {
  light: 'Use the screen light in SOS tools',
  sound: 'Use the SOS sound in SOS tools',
}

function SectionIcon({ icon }) {
  if (icon === 'medical') return <HeartPulse className="size-5 shrink-0 text-danger" aria-hidden="true" />
  if (icon === 'general') return <Users className="size-5 shrink-0 text-teal-300" aria-hidden="true" />
  return <EmergencyIcon typeId={icon} className="size-5 shrink-0 text-caution" />
}

/** Survival and first-aid guide. Read it before you need it. */
export default function GuidePage() {
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-3xl font-bold text-white sm:text-4xl">Survival guide</h1>
      <p className="mt-2 text-slate-400">
        What to do when you’re caught in an emergency. Read it now, while it’s calm. General guidance only: always follow
        emergency personnel and get first-aid training if you can.
      </p>

      <nav aria-label="Guide topics" className="mt-6 flex flex-wrap gap-2">
        {GUIDE_SECTIONS.map((section) => (
          <a
            key={section.id}
            href={`#${section.id}`}
            className={`rounded-full border px-3 py-1 text-sm transition-colors ${
              section.urgent ? 'border-danger/50 text-red-100 hover:bg-danger/15' : 'border-white/15 text-slate-300 hover:border-white/30 hover:text-white'
            }`}
          >
            {section.title}
          </a>
        ))}
      </nav>

      <div className="mt-8 space-y-3">
        {GUIDE_SECTIONS.map((section, index) => (
          <details
            key={section.id}
            id={section.id}
            open={index < 2}
            className={`group rounded-2xl border bg-navy-900 ${section.urgent ? 'border-danger/40' : 'border-white/10'}`}
          >
            <summary className="flex cursor-pointer list-none items-center gap-3 px-5 py-4 [&::-webkit-details-marker]:hidden">
              <SectionIcon icon={section.icon} />
              <h2 className="flex-1 font-display text-xl font-semibold text-white">{section.title}</h2>
              <span className="text-sm text-slate-400 group-open:hidden">Show</span>
              <span className="hidden text-sm text-slate-400 group-open:inline">Hide</span>
            </summary>
            <div className="border-t border-white/10 px-5 pb-5 pt-4">
              <ol className="list-decimal space-y-2 pl-5 leading-relaxed text-slate-200 marker:text-slate-500">
                {section.steps.map((step) => (
                  <li key={step}>{step}</li>
                ))}
              </ol>
              {section.avoid && (
                <div className="mt-4 rounded-xl bg-danger/10 p-4">
                  <h3 className="text-sm font-semibold text-red-200">Don’t</h3>
                  <ul className="mt-2 space-y-1 text-sm text-red-50">
                    {section.avoid.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              )}
              {section.tool && (
                <Link to="/sos" className="mt-4 inline-flex text-sm font-semibold text-teal-300 hover:text-teal-200">
                  {TOOL_LINKS[section.tool]}
                </Link>
              )}
            </div>
          </details>
        ))}
      </div>
    </div>
  )
}
