import { Link, useNavigate } from 'react-router-dom'
import {
  Accessibility,
  Check,
  GitBranch,
  Layers,
  LifeBuoy,
  Map as MapIcon,
  MapPinned,
  Phone,
  ShieldCheck,
  Siren,
  TriangleAlert,
} from 'lucide-react'
import EvacuationPlanIllustration from '../components/landing/EvacuationPlanIllustration.jsx'
import Logo from '../components/Logo.jsx'
import PrototypeNotice from '../components/PrototypeNotice.jsx'
import { useEmergency } from '../context/EmergencyContext.jsx'

const FEATURES = [
  {
    icon: ShieldCheck,
    title: 'Safety before speed',
    text: 'Routes are chosen only from paths that are open and clear of known hazards. Only then is the quickest one picked.',
  },
  {
    icon: GitBranch,
    title: 'Reroutes when a path closes',
    text: "When a walkway is blocked, the route is recalculated around it. If no safe route is left, the app says so plainly instead of guessing.",
  },
  {
    icon: Layers,
    title: 'Guidance for each emergency',
    text: 'Fire, earthquake, flood and chemical incidents each have their own allowed destinations, path restrictions and instructions.',
  },
  {
    icon: Accessibility,
    title: 'Step-free routes',
    text: 'Ask for a route without stairs or steps, with clear advice for when you will need assistance.',
  },
  {
    icon: LifeBuoy,
    title: 'Help when there is no route',
    text: 'Call 112, send your building, room and GPS position, light up your screen or play an SOS signal so rescuers can find you.',
  },
  {
    icon: MapPinned,
    title: 'Mapped by students, on the real campus',
    text: 'Survey UPES Bidholi on a real map: mark buildings, walkways, stairs and official assembly points, then share the data with your team.',
  },
]

const STEPS = [
  { title: 'Tell it where you are', text: 'Pick your building from the list, or tap it on the campus map.' },
  { title: 'Choose the emergency', text: 'The type of emergency decides which destinations and paths are allowed.' },
  { title: 'Unsafe paths are removed', text: 'Blocked walkways and hazard zones are taken out before any route is calculated.' },
  { title: 'Follow the route', text: 'See the distance, walking time and step-by-step directions to your destination.' },
]

const PREPAREDNESS = [
  'Know two ways out of every building you use regularly.',
  'Learn where your assembly points are, and which one applies to which emergency.',
  'Never use elevators during a fire unless emergency personnel tell you to.',
  'If you may need help to evacuate, agree a personal evacuation plan with your department.',
  "Save campus security's number in your phone today.",
  'Take part in evacuation drills. They are the best practice you will get.',
]

export default function LandingPage() {
  const navigate = useNavigate()
  const { startEmergency } = useEmergency()

  function handleEmergencyMode() {
    startEmergency()
    navigate('/dashboard')
  }

  return (
    <div className="min-h-dvh bg-navy-950 text-slate-100">
      <PrototypeNotice />

      <header className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-5 sm:px-8">
        <Link to="/" aria-label="CampusSafe AI home page">
          <Logo />
        </Link>
        <nav aria-label="Page sections" className="hidden items-center gap-8 text-[15px] text-slate-300 md:flex">
          <a href="#features" className="transition-colors hover:text-white">
            Features
          </a>
          <a href="#how-it-works" className="transition-colors hover:text-white">
            How it works
          </a>
          <a href="#preparedness" className="transition-colors hover:text-white">
            Preparedness
          </a>
        </nav>
        <Link
          to="/dashboard"
          className="rounded-xl border border-white/15 px-4 py-2 text-sm font-semibold text-white transition-colors hover:border-teal-300/60 hover:text-teal-100"
        >
          Open dashboard
        </Link>
      </header>

      <main>
        {/* Hero */}
        <section className="mx-auto grid max-w-6xl items-center gap-12 px-5 pb-20 pt-8 sm:px-8 lg:grid-cols-[1.05fr_1fr] lg:pt-14">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-teal-300/30 bg-teal-400/10 px-3 py-1 text-sm text-teal-100">
              <ShieldCheck className="size-4" aria-hidden="true" />
              University emergency evacuation prototype
            </p>
            <h1 className="mt-6 font-display text-5xl font-bold leading-[0.95] tracking-tight text-white sm:text-6xl lg:text-7xl">
              Navigate Safely.
              <br />
              Escape Smarter.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-slate-300">
              CampusSafe AI helps UPES Bidholi students get from where they are to a designated exit or assembly point. It
              skips paths that are blocked or affected by the hazard, and when no route is possible, it helps you call,
              signal and survive until help arrives.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                to="/dashboard"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-teal-400 px-6 py-3.5 font-semibold text-navy-950 transition-colors hover:bg-teal-300"
              >
                <MapIcon className="size-5" aria-hidden="true" />
                Open Campus Map
              </Link>
              <button
                type="button"
                onClick={handleEmergencyMode}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-danger px-6 py-3.5 font-semibold text-white transition-colors hover:bg-red-500"
              >
                <Siren className="size-5" aria-hidden="true" />
                Emergency Mode
              </button>
            </div>
            <p className="mt-4 text-sm text-slate-400">
              Emergency Mode starts a practice evacuation.{' '}
              <Link to="/sos" className="font-semibold text-teal-300 hover:text-teal-200">
                SOS tools
              </Link>{' '}
              work right away.
            </p>
          </div>

          <EvacuationPlanIllustration />
        </section>

        {/* Features */}
        <section id="features" aria-labelledby="features-heading" className="border-t border-white/10 bg-navy-900/50">
          <div className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
            <div className="max-w-2xl">
              <h2 id="features-heading" className="font-display text-3xl font-bold text-white sm:text-4xl">
                Safety first, then speed
              </h2>
              <p className="mt-3 text-lg text-slate-300">
                Every route is chosen in two passes: unsafe paths are removed, then the quickest of what remains is
                picked.
              </p>
            </div>
            <dl className="mt-12 grid gap-x-14 gap-y-10 md:grid-cols-2">
              {FEATURES.map(({ icon: Icon, title, text }) => (
                <div key={title} className="flex gap-4">
                  <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-teal-400/10 text-teal-300 ring-1 ring-teal-300/20">
                    <Icon className="size-5" aria-hidden="true" />
                  </span>
                  <div>
                    <dt className="font-display text-xl font-semibold text-white">{title}</dt>
                    <dd className="mt-1.5 leading-relaxed text-slate-400">{text}</dd>
                  </div>
                </div>
              ))}
            </dl>
          </div>
        </section>

        {/* How it works: a real sequence, so numbered steps are appropriate */}
        <section id="how-it-works" aria-labelledby="how-heading" className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
          <h2 id="how-heading" className="font-display text-3xl font-bold text-white sm:text-4xl">
            How it works
          </h2>
          <ol className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((step, index) => {
              const isLast = index === STEPS.length - 1
              return (
                <li key={step.title} className={`border-l-2 pl-5 ${isLast ? 'border-safe' : 'border-teal-300/40'}`}>
                  <span className={`font-display text-4xl font-bold ${isLast ? 'text-safe' : 'text-teal-300/80'}`}>
                    {index + 1}
                  </span>
                  <h3 className="mt-2 font-display text-xl font-semibold text-white">{step.title}</h3>
                  <p className="mt-2 leading-relaxed text-slate-400">{step.text}</p>
                </li>
              )
            })}
          </ol>
        </section>

        {/* Preparedness */}
        <section id="preparedness" aria-labelledby="prep-heading" className="border-t border-white/10 bg-navy-900/50">
          <div className="mx-auto grid max-w-6xl gap-12 px-5 py-20 sm:px-8 lg:grid-cols-[1.2fr_1fr]">
            <div>
              <h2 id="prep-heading" className="font-display text-3xl font-bold text-white sm:text-4xl">
                Before an emergency happens
              </h2>
              <p className="mt-3 text-lg text-slate-300">Most of a safe evacuation is decided before the alarm sounds.</p>
              <ul className="mt-8 space-y-4">
                {PREPAREDNESS.map((item) => (
                  <li key={item} className="flex gap-3">
                    <Check className="mt-0.5 size-5 shrink-0 text-safe" aria-hidden="true" />
                    <span className="leading-relaxed text-slate-300">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <aside aria-labelledby="prototype-heading" className="self-start rounded-2xl border-2 border-caution/60 bg-caution/5 p-6">
              <div className="flex items-center gap-3">
                <TriangleAlert className="size-6 shrink-0 text-caution" aria-hidden="true" />
                <h2 id="prototype-heading" className="font-display text-2xl font-bold text-white">
                  This is a prototype
                </h2>
              </div>
              <p className="mt-4 leading-relaxed text-slate-300">
                CampusSafe AI uses student-surveyed map data and simulated hazards. It is not approved by UPES for real
                evacuations, and it does not monitor live conditions.
              </p>
              <p className="mt-3 leading-relaxed text-slate-300">
                In an emergency, follow alarms, exit signs and instructions from authorized campus emergency personnel.
              </p>
              <Link
                to="/contacts"
                className="mt-6 inline-flex items-center gap-2 font-semibold text-teal-300 transition-colors hover:text-teal-200"
              >
                <Phone className="size-4" aria-hidden="true" />
                Emergency contacts
              </Link>
            </aside>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/10">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-5 py-8 text-sm text-slate-400 sm:flex-row sm:items-center sm:justify-between sm:px-8">
          <Logo />
          <p>Final-year project prototype. Not for real-world emergency use.</p>
        </div>
      </footer>
    </div>
  )
}
