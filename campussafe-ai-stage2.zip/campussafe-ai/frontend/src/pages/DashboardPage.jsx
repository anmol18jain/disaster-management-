import CampusStatusCard from '../components/dashboard/CampusStatusCard.jsx'
import ContactsMiniCard from '../components/dashboard/ContactsMiniCard.jsx'
import DashboardMap from '../components/dashboard/DashboardMap.jsx'
import EmergencyWizard from '../components/dashboard/EmergencyWizard.jsx'
import NavigationStepsPanel from '../components/dashboard/NavigationStepsPanel.jsx'
import RouteInfoPanel from '../components/dashboard/RouteInfoPanel.jsx'
import SafetyGuidanceCard from '../components/dashboard/SafetyGuidanceCard.jsx'
import SelectionPanel from '../components/dashboard/SelectionPanel.jsx'
import { useCampus } from '../context/CampusContext.jsx'
import { useEmergency } from '../context/EmergencyContext.jsx'

/**
 * Student dashboard.
 * Left (wide) column: selections, campus map, route and directions.
 * Right column: status, safety guidance and contacts.
 * On phones the columns stack in that same order.
 */
export default function DashboardPage() {
  const { startEmergency, wizardOpen } = useEmergency()
  const { campus } = useCampus()

  return (
    <div className="mx-auto max-w-7xl">
      <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-white sm:text-4xl">Evacuation dashboard</h1>
          <p className="mt-1 text-slate-400">
            {campus.name}.{' '}
            {campus.isFictional
              ? 'A fictional campus for demonstrations.'
              : 'Map data comes from your own survey and is not approved by campus safety staff.'}
          </p>
        </div>

        <button
          type="button"
          onClick={startEmergency}
          className="inline-flex w-full items-center justify-center gap-3 rounded-2xl bg-danger px-6 py-4 font-display text-lg font-bold uppercase tracking-wide text-white shadow-lg shadow-red-950/50 transition hover:bg-red-500 active:scale-[0.98] sm:w-auto"
        >
          <span className="relative flex size-3" aria-hidden="true">
            <span className="absolute inline-flex size-full animate-ping-slow rounded-full bg-white" />
            <span className="relative inline-flex size-3 rounded-full bg-white" />
          </span>
          Start emergency navigation
        </button>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <SelectionPanel />
          <DashboardMap />
          <div className="grid gap-6 md:grid-cols-2">
            <RouteInfoPanel />
            <NavigationStepsPanel />
          </div>
        </div>

        <div className="space-y-6">
          <CampusStatusCard />
          <SafetyGuidanceCard />
          <ContactsMiniCard />
        </div>
      </div>

      {/* The dialog is only added to the page while it is open. */}
      {wizardOpen && <EmergencyWizard />}
    </div>
  )
}
