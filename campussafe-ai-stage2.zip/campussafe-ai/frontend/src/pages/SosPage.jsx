import { Ambulance, Flame, Phone } from 'lucide-react'
import MedicalCard from '../components/sos/MedicalCard.jsx'
import SafeCheckInCard from '../components/sos/SafeCheckInCard.jsx'
import ScreenLightCard from '../components/sos/ScreenLightCard.jsx'
import ShareLocationCard from '../components/sos/ShareLocationCard.jsx'
import SosSoundCard from '../components/sos/SosSoundCard.jsx'

/** Tools that help in any emergency, even when no route can be calculated. */
export default function SosPage() {
  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-display text-3xl font-bold text-white sm:text-4xl">SOS tools</h1>
      <p className="mt-1 max-w-2xl text-slate-400">Call for help, signal where you are and keep people informed. These tools work on any campus.</p>

      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <a
          href="tel:112"
          className="flex items-center justify-center gap-3 rounded-2xl bg-danger px-5 py-4 font-display text-xl font-bold text-white shadow-lg shadow-red-950/50 hover:bg-red-500 sm:col-span-3"
        >
          <Phone className="size-6" aria-hidden="true" />
          Call 112
          <span className="text-base font-medium text-red-100">(police, fire, ambulance)</span>
        </a>
        <a href="tel:108" className="flex items-center justify-center gap-2 rounded-xl border border-white/15 px-4 py-3 font-semibold text-white hover:border-white/30">
          <Ambulance className="size-5 text-danger" aria-hidden="true" /> Ambulance 108
        </a>
        <a href="tel:101" className="flex items-center justify-center gap-2 rounded-xl border border-white/15 px-4 py-3 font-semibold text-white hover:border-white/30">
          <Flame className="size-5 text-danger" aria-hidden="true" /> Fire 101
        </a>
        <a href="tel:1906" className="flex items-center justify-center gap-2 rounded-xl border border-white/15 px-4 py-3 font-semibold text-white hover:border-white/30">
          Gas leak 1906
        </a>
      </div>
      <p className="mt-2 text-xs text-slate-500">Numbers for Uttarakhand, India, checked October 2026. Your phone will ask before calling.</p>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <ShareLocationCard />
        <div className="space-y-6">
          <ScreenLightCard />
          <SosSoundCard />
        </div>
        <SafeCheckInCard />
        <MedicalCard />
      </div>
    </div>
  )
}
