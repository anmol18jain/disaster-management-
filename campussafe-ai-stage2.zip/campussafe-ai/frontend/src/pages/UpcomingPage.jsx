import { CircleDashed, Lock } from 'lucide-react'
import { Link } from 'react-router-dom'

/** Placeholder for a page planned in a later stage. Explains what is coming. */
export default function UpcomingPage({ title, stage, summary, items = [], note }) {
  return (
    <div className="mx-auto max-w-3xl">
      <span className="inline-flex rounded-full border border-white/15 px-3 py-1 text-sm text-slate-300">
        Planned for Stage {stage}
      </span>
      <h1 className="mt-4 font-display text-3xl font-bold text-white sm:text-4xl">{title}</h1>
      <p className="mt-2 text-lg text-slate-400">{summary}</p>

      <ul className="mt-8 space-y-3">
        {items.map((item) => (
          <li key={item} className="flex gap-3 text-slate-300">
            <CircleDashed className="mt-0.5 size-5 shrink-0 text-teal-300" aria-hidden="true" />
            {item}
          </li>
        ))}
      </ul>

      {note && (
        <div role="note" className="mt-8 flex gap-3 rounded-2xl border border-caution/40 bg-caution/10 p-4">
          <Lock className="mt-0.5 size-5 shrink-0 text-caution" aria-hidden="true" />
          <p className="text-sm leading-relaxed text-amber-50">{note}</p>
        </div>
      )}

      <Link
        to="/dashboard"
        className="mt-8 inline-flex rounded-xl bg-teal-400 px-5 py-2.5 text-sm font-semibold text-navy-950 transition-colors hover:bg-teal-300"
      >
        Back to dashboard
      </Link>
    </div>
  )
}
