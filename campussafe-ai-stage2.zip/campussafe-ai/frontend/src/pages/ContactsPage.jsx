import { TriangleAlert } from 'lucide-react'
import ContactCard from '../components/ContactCard.jsx'
import { CONTACT_GROUPS, EMERGENCY_CONTACTS } from '../data/contacts.js'

const WHAT_TO_SAY = [
  'Where you are: building, floor and room, or the nearest landmark.',
  'What is happening: fire, injury, chemical spill, flooding, and so on.',
  'How many people are hurt or need help, including anyone who cannot use stairs.',
  'A number they can call you back on.',
]

/** Emergency assistance page. Numbers come from src/data/contacts.js. */
export default function ContactsPage() {
  const missingNumbers = EMERGENCY_CONTACTS.some((contact) => !contact.phone)

  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="font-display text-3xl font-bold text-white sm:text-4xl">Emergency contacts</h1>
      <p className="mt-2 max-w-2xl text-slate-400">
        Who to call in an emergency. If you are in immediate danger, get to safety first, then call.
      </p>

      {missingNumbers && (
        <div role="note" className="mt-6 flex gap-3 rounded-2xl border border-caution/40 bg-caution/10 p-4">
          <TriangleAlert className="mt-0.5 size-5 shrink-0 text-caution" aria-hidden="true" />
          <p className="text-sm leading-relaxed text-amber-50">
            <strong className="font-semibold">Campus numbers are not configured.</strong> This app never shows guessed
            numbers. Ask the UPES security office for verified numbers and add them in{' '}
            <code className="rounded bg-black/30 px-1.5 py-0.5 text-xs">src/data/contacts.js</code>.
          </p>
        </div>
      )}

      {CONTACT_GROUPS.map((group) => (
        <section key={group.id} aria-labelledby={`group-${group.id}`} className="mt-8">
          <h2 id={`group-${group.id}`} className="font-display text-xl font-semibold text-white">
            {group.title}
          </h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            {EMERGENCY_CONTACTS.filter((contact) => contact.group === group.id).map((contact) => (
              <ContactCard key={contact.id} contact={contact} />
            ))}
          </div>
        </section>
      ))}

      <section aria-labelledby="say-heading" className="mt-10 rounded-2xl border border-white/10 bg-navy-900 p-6">
        <h2 id="say-heading" className="font-display text-xl font-semibold text-white">
          When you call, tell them
        </h2>
        <ul className="mt-4 space-y-2.5">
          {WHAT_TO_SAY.map((item) => (
            <li key={item} className="flex gap-3 text-slate-300">
              <span className="mt-2 size-1.5 shrink-0 rounded-full bg-teal-300" aria-hidden="true" />
              {item}
            </li>
          ))}
        </ul>
        <p className="mt-5 text-sm text-slate-400">Stay on the line until the operator tells you to hang up.</p>
      </section>
    </div>
  )
}
