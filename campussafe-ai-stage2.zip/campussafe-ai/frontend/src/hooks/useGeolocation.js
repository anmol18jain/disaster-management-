import { useCallback, useState } from 'react'

const ERROR_MESSAGES = {
  1: 'Location permission was denied. Allow it in your browser settings, or choose your location manually.',
  2: 'Your position is unavailable. GPS often fails indoors, so choose your location manually.',
  3: 'Finding your position took too long. Try again outdoors, or choose your location manually.',
}

/**
 * Asks the device for its GPS position once, when locate() is called.
 * Browsers only allow this on https:// pages or on localhost.
 */
export function useGeolocation() {
  const supported = typeof navigator !== 'undefined' && 'geolocation' in navigator
  const [state, setState] = useState({ status: 'idle', position: null, error: null })

  const locate = useCallback(() => {
    if (!supported) {
      setState({ status: 'error', position: null, error: 'This browser cannot share your location.' })
      return
    }
    setState((previous) => ({ ...previous, status: 'locating', error: null }))
    navigator.geolocation.getCurrentPosition(
      (result) =>
        setState({
          status: 'ready',
          error: null,
          position: {
            lat: result.coords.latitude,
            lng: result.coords.longitude,
            accuracy: Math.round(result.coords.accuracy),
            timestamp: result.timestamp,
          },
        }),
      (error) =>
        setState((previous) => ({
          ...previous,
          status: 'error',
          error: ERROR_MESSAGES[error.code] ?? 'Could not get your position.',
        })),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 },
    )
  }, [supported])

  return { ...state, supported, locate }
}
