import { useCallback, useEffect, useRef, useState } from 'react'

const UNIT_SECONDS = 0.15 // length of one Morse "dot"
const FREQUENCY_HZ = 2800 // high pitch, like a whistle: carries well and is easy to hear

/** SOS in Morse code (... --- ...) as [startUnit, lengthUnits] tones, then a pause. */
function buildPattern() {
  const letters = [
    [1, 1, 1],
    [3, 3, 3],
    [1, 1, 1],
  ]
  const tones = []
  let unit = 0
  letters.forEach((letter, letterIndex) => {
    letter.forEach((length, signalIndex) => {
      tones.push([unit, length])
      unit += length
      if (signalIndex < letter.length - 1) unit += 1
    })
    if (letterIndex < letters.length - 1) unit += 3
  })
  return { tones, cycleUnits: unit + 7 }
}

const PATTERN = buildPattern()

/** Plays a repeating SOS signal through the speaker until stopped. */
export function useSosSound() {
  const contextRef = useRef(null)
  const timerRef = useRef(null)
  const [playing, setPlaying] = useState(false)
  const supported = typeof window !== 'undefined' && Boolean(window.AudioContext || window.webkitAudioContext)

  const stop = useCallback(() => {
    clearInterval(timerRef.current)
    timerRef.current = null
    contextRef.current?.close().catch(() => {})
    contextRef.current = null
    setPlaying(false)
  }, [])

  const start = useCallback(() => {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext
    if (!AudioContextClass || contextRef.current) return
    const context = new AudioContextClass()
    contextRef.current = context

    const scheduleCycle = (cycleStart) => {
      for (const [offset, length] of PATTERN.tones) {
        const oscillator = context.createOscillator()
        const gain = context.createGain()
        oscillator.type = 'square'
        oscillator.frequency.value = FREQUENCY_HZ
        const begin = cycleStart + offset * UNIT_SECONDS
        const end = begin + length * UNIT_SECONDS
        gain.gain.setValueAtTime(0, begin)
        gain.gain.linearRampToValueAtTime(0.6, begin + 0.01)
        gain.gain.setValueAtTime(0.6, end - 0.01)
        gain.gain.linearRampToValueAtTime(0, end)
        oscillator.connect(gain)
        gain.connect(context.destination)
        oscillator.start(begin)
        oscillator.stop(end + 0.02)
      }
    }

    let nextCycle = context.currentTime + 0.05
    scheduleCycle(nextCycle)
    nextCycle += PATTERN.cycleUnits * UNIT_SECONDS
    // Keep scheduling the next cycle shortly before the current one ends.
    timerRef.current = setInterval(() => {
      if (context.currentTime > nextCycle - 1) {
        scheduleCycle(nextCycle)
        nextCycle += PATTERN.cycleUnits * UNIT_SECONDS
      }
    }, 250)
    setPlaying(true)
  }, [])

  useEffect(() => stop, [stop]) // stop the sound if the page is left

  return { playing, start, stop, supported }
}
