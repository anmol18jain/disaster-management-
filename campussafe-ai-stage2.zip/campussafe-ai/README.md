# CampusSafe AI

A prototype emergency evacuation website for students at UPES Bidholi, Dehradun. It helps a student say where they are and what kind of emergency is happening, then (from Stage 3) calculates a route to a designated exit or assembly point using only paths considered safe. When no route is possible, its SOS tools and survival guide help them call, signal and survive until help arrives.

> **Prototype only.** Map data is student-surveyed and not approved by UPES; hazards are simulated. Nothing here is approved for real evacuations, and no live data is connected. In a real emergency, follow alarms, exit signs and authorized campus emergency personnel.

## Current status: Stage 2 of 6

| Stage | What it adds | Status |
| --- | --- | --- |
| 1 | React + Tailwind setup, landing page, dashboard, contacts page | Done |
| 2 | Real UPES Bidholi map, campus mapper, GPS help, SOS tools, survival guide | Done |
| 3 | A* routing on your mapped walkways: route line, distance, time, directions | Next |
| 4 | Simulated hazards, blocked paths, automatic rerouting | Planned |
| 5 | Admin dashboard (demo, not secured) | Planned |
| 6 | Node/Express backend, Socket.IO, PostgreSQL + PostGIS schema | Planned |

### What's new in Stage 2

- **Two campuses.** *UPES Bidholi* uses a real OpenStreetMap or satellite map and **your own survey data**. The *demo campus* is fictional and ready for presentations. Switch between them in the sidebar.
- **Campus mapper** (`/mapper`): add buildings, gates, assembly points and refuges; draw walkways (with junctions for bends); mark stairs, slopes and low-lying stretches; tick "verified on site". Data saves in the browser automatically and can be **exported/imported as JSON**, so your team can share one survey.
- **GPS help** on the dashboard: shows your position and accuracy outdoors, and suggests the nearest mapped building, which you confirm yourself.
- **SOS tools** (`/sos`): one-tap 112/108/101/1906; a help message with building, room and GPS (share via WhatsApp, SMS or copy); a full-screen light; a loud SOS sound; an "I'm safe" message; and an optional medical card stored only on the device.
- **Survival guide** (`/guide`): trapped in a fire, clothes on fire, burns, smoke, earthquake and trapped under debris, landslide, flood, LPG leak, lab spill, electric shock, hands-only CPR, crowd crush.
- **Landslide** added as an emergency type (Bidholi is in the hills).

### Why the UPES map starts empty

No verified, public map of UPES buildings and assembly points was available. Guessing them would be dangerous, so the app ships with **no UPES buildings** and an **approximate** starting view. You build the real data by surveying:

1. Ask the UPES safety or estate office for the official evacuation plan and designated assembly points.
2. Open **Campus mapper**, pan to the campus and press **Save this view**.
3. Switch to satellite view and add each building and its exits. On site, use **Add at my position**.
4. Draw walkways between exits, junctions and assembly points. Untick **Step-free** wherever there are steps.
5. Only tick an emergency type under "Official evacuation destination" if UPES designates that place for it.
6. Tick **Verified on site** only after checking in person. **Export** regularly as a backup.

## Run it in VS Code

You need **Node.js 20 or newer** (the LTS version from https://nodejs.org is best) and **VS Code**.

1. Unzip the project and open the `campussafe-ai` folder in VS Code (**File → Open Folder**).
2. Open a terminal: **Terminal → New Terminal**.
3. Check Node is installed:
   ```bash
   node -v
   ```
   You should see `v20.x` or higher.
4. Go into the frontend folder and install the packages (first time only, takes a minute):
   ```bash
   cd frontend
   npm install
   ```
5. Start the development server:
   ```bash
   npm run dev
   ```
6. Open the address it prints, usually http://localhost:5173.

> Upgrading from Stage 1? Run `npm install` again: Stage 2 adds `leaflet` and `react-leaflet`.

Leave the terminal running while you work. Saving a file updates the browser automatically. Press `Ctrl + C` in the terminal to stop the server.

## How to test Stage 2

1. **Dashboard** (UPES Bidholi selected): it says the campus isn't mapped yet. Press **Try the demo campus** and check that the map shows labelled buildings and green assembly points.
2. On the demo campus, tap a building on the map. It turns red, and the location dropdown updates. Choose **Landslide**: only Assembly Point A is highlighted and listed.
3. Switch back to **UPES Bidholi** in the sidebar and open **Campus mapper**. Add a building, add an assembly point with *Fire* ticked, then draw a walkway between them.
4. Reload the page. Your survey is still there. Press **Export**, delete a place, then **Import** the file to restore it.
5. On the dashboard, choose that building and *Fire*: your assembly point is listed. Choose *Flood*: the app says no suitable destination exists instead of inventing one.
6. **SOS tools**: type a room number, press **Add GPS position**, then **Copy**, and paste somewhere to check the message. Try the screen light and the SOS sound.
7. **Survival guide**: the topic chips jump to each section.

### Testing GPS on your phone

Browsers only allow GPS on `https://` pages or `localhost`. Opening the dev server from your phone over Wi-Fi (`npm run dev -- --host`) uses plain `http://`, so GPS will be blocked there. Options:

- Deploy the built site for free on Netlify or Vercel (both give you `https://`). Run `npm run build` and upload the `dist` folder.
- Or test GPS on your laptop at `localhost`, and use the phone only for layout checks.

## Project structure

```
campussafe-ai/
├── README.md
└── frontend/
    ├── index.html                 Page shell, fonts, favicon
    ├── package.json               Dependencies and npm scripts
    ├── vite.config.js             Vite + React + Tailwind plugins
    └── src/
        ├── main.jsx               Entry point: router + shared state
        ├── App.jsx                Page routes
        ├── App.css                Tailwind import, colours, fonts, animations
        ├── context/
        │   ├── CampusContext.jsx      Active campus + survey data (saved in the browser)
        │   └── EmergencyContext.jsx   Your location, emergency type, emergency mode
        ├── data/
        │   ├── campuses/              UPES Bidholi config (no guessed buildings) + fictional demo
        │   ├── emergencyTypes.js      Rules and instructions per emergency
        │   ├── survivalGuide.js       Survival and first-aid guide content
        │   └── contacts.js            Public numbers (sourced) + campus placeholders
        ├── hooks/                     useGeolocation (GPS), useSosSound (SOS audio)
        ├── utils/                     Campus lookups, distances, survey validation, messages
        ├── pages/                     One file per page
        └── components/
            ├── map/                   CampusMap (Leaflet) + marker icons
            ├── mapper/                Place and walkway editors
            ├── sos/                   SOS tool cards
            ├── layout/                Sidebar, top bar, page frame
            ├── dashboard/             Dashboard panels and the emergency dialog
            └── landing/               Landing-page illustration
```

The `backend/` folder is added in Stage 6.

## Emergency contacts

Public numbers (112, 108, 101, 1906) were checked in October 2026 against Uttarakhand government sources, which are listed in `frontend/src/data/contacts.js`. Re-check them before a demo. **Campus numbers are empty on purpose**: get the verified 24x7 security and health-centre numbers from UPES and add them in that file.

## Map tiles and data notes

- Street map: © OpenStreetMap contributors. Satellite: © Esri and partners. Both are fine for development and demos, but check their usage policies before a public launch.
- Survey data lives in the browser's localStorage. Clearing browser data deletes it, so **export often**.
- Imported files are checked and cleaned (`utils/survey.js`), and place names are escaped before they're shown on the map.

## Troubleshooting

- **`npm` is not recognized**: Node.js isn't installed, or VS Code was open during installation. Install Node.js, then fully restart VS Code.
- **Windows: "running scripts is disabled on this system"**: in the VS Code terminal dropdown choose **Command Prompt** instead of PowerShell, or run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` once in PowerShell.
- **Port 5173 already in use**: Vite picks the next free port automatically; use the address it prints.
- **Blank white page**: open the browser console (`F12` → Console) and read the first red error. It names the file and line.
- **Install errors about versions**: delete `node_modules` and `package-lock.json`, then run `npm install` again.
- **Map is grey or blank**: map tiles need internet. Check your connection; the demo campus works without tiles.
- **"Location permission was denied"**: allow location for the site in browser settings, and make sure the page is `https://` or `localhost`.

## Design notes

- Colours follow safety-sign meanings: green for safe routes and assembly points, red for emergencies and "you are here", yellow for caution and missing data.
- Barlow, a typeface modelled on road signage, is used throughout. If it can't load, the app falls back to system fonts.
- Location is chosen manually because GPS can't reliably place someone inside a building.
- Where the app lacks data (live hazards, wind direction, verified numbers) it says so, rather than implying it knows.
